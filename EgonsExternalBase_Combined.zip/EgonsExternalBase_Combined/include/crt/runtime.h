/**
 * EgonsExternalBase - CRT Runtime Compatibility
 * Provides CRT functions referenced in the decompilation
 */

#pragma once

#include "core/common.h"

namespace crt {

// ============================================================================
// Runtime Initialization
// ============================================================================

/**
 * Initialize CRT
 */
void init();

/**
 * Terminate CRT
 */
void terminate();

/**
 * Initialize multi-byte support
 */
void init_multibyte();

/**
 * Update locale info
 */
void update_locale_info(void* context, void** locale_data);

/**
 * Update locale info (multi-byte)
 */
void update_locale_info_mb(void* context, void** locale_data);

/**
 * Lock CRT section
 */
void lock(int section_index);

/**
 * Unlock CRT section
 */
void unlock(int section_index);

// ============================================================================
// Argument Parsing
// ============================================================================

/**
 * Parse command line into arguments
 */
void parse_command_line();

/**
 * Get command line arguments
 */
wchar_t** get_command_line(int* argc);

/**
 * Get initial environment
 */
wchar_t** get_environment();

// ============================================================================
// Exit Handling
// ============================================================================

/**
 * Register atexit function
 */
int register_atexit(void (*func)(void));

/**
 * Execute atexit functions
 */
void execute_atexit();

/**
 * Exit with code
 */
[[noreturn]] void exit_process(int code);

/**
 * Quick exit
 */
[[noreturn]] void quick_exit(int code);

/**
 * Abort
 */
[[noreturn]] void abort_process();

/**
 * Set abort message
 */
void set_abort_message(const wchar_t* message);

// ============================================================================
// Error Handling
// ============================================================================

/**
 * Invoke Watson (error reporting)
 */
[[noreturn]] void invoke_watson(const wchar_t* expression, const wchar_t* function_name,
                                 const wchar_t* file_name, uint32_t line, uintptr_t reserved);

/**
 * Set error mode
 */
int set_error_mode(int mode);

/**
 * Get last error
 */
uint32_t get_last_error();

/**
 * Set last error
 */
void set_last_error(uint32_t error);

/**
 * Get error string
 */
const char* get_error_string(uint32_t error);

// ============================================================================
// Locale Support
// ============================================================================

/**
 * Get locale info
 */
void* get_locale_info();

/**
 * Set locale
 */
char* set_lc(int category, const char* locale);

/**
 * Get current locale name
 */
const char* get_current_locale_name();

/**
 * Configure new handler
 */
void* configure_new_handler();

// ============================================================================
// Multi-byte Support
// ============================================================================

/**
 * Initialize multi-byte conversion
 */
void init_multibyte_tables();

/**
 * Get code page
 */
uint32_t get_code_page();

/**
 * Get ACP (ANSI code page)
 */
uint32_t get_acp();

/**
 * Get thread multi-byte info
 */
void* get_thread_mb_info();

// ============================================================================
// Floating Point
// ============================================================================

/**
 * Get floating point precision
 */
uint32_t get_floating_point_precision();

/**
 * Set floating point control
 */
uint32_t set_floating_point_control(uint32_t new_control, uint32_t mask);

/**
 * Get floating point status
 */
uint32_t get_floating_point_status();

/**
 * Clear floating point status
 */
uint32_t clear_floating_point_status(uint32_t mask);

/**
 * Check floating point exception
 */
int check_floating_point_exception(uint32_t exception);

// ============================================================================
// Heap Management
// ============================================================================

/**
 * Get process heap
 */
void* get_process_heap();

/**
 * Heap allocate
 */
void* heap_alloc(void* heap, uint32_t flags, size_t size);

/**
 * Heap reallocate
 */
void* heap_realloc(void* heap, uint32_t flags, void* ptr, size_t size);

/**
 * Heap free
 */
bool heap_free(void* heap, uint32_t flags, void* ptr);

/**
 * Heap size
 */
size_t heap_size(void* heap, uint32_t flags, const void* ptr);

/**
 * Heap validate
 */
bool heap_validate(void* heap, uint32_t flags, const void* ptr);

/**
 * Heap compact
 */
size_t heap_compact(void* heap, uint32_t flags);

/**
 * Heap destroy
 */
bool heap_destroy(void* heap);

/**
 * Heap lock
 */
bool heap_lock(void* heap);

/**
 * Heap unlock
 */
bool heap_unlock(void* heap);

// ============================================================================
// Parameter Validation
// ============================================================================

/**
 * Validate parameter
 */
void validate_parameter(const wchar_t* expression, const wchar_t* function_name,
                        const wchar_t* file_name, uint32_t line, uintptr_t reserved);

/**
 * Invalid parameter handler
 */
void invalid_parameter_handler(const wchar_t* expression, const wchar_t* function_name,
                                const wchar_t* file_name, uint32_t line, uintptr_t reserved);

/**
 * Set invalid parameter handler
 */
void set_invalid_parameter_handler(void (*handler)(const wchar_t*, const wchar_t*,
                                                     const wchar_t*, uint32_t, uintptr_t));

/**
 * Purge invalid parameter handler
 */
void purge_invalid_parameter_handler();

// ============================================================================
// Security
// ============================================================================

/**
 * Check security cookie (buffer overflow detection)
 */
void security_check_cookie(uintptr_t cookie);

/**
 * Setup security cookie
 */
uintptr_t security_setup_cookie();

/**
 * Report GS failure
 */
[[noreturn]] void security_report_failure();

/**
 * Check stack corruption
 */
void security_check_stack_corruption();

// ============================================================================
// Signal Handling
// ============================================================================

/**
 * Signal handler function type
 */
using SignalHandler = void(*)(int);

/**
 * Set signal handler
 */
SignalHandler set_signal(int signal, SignalHandler handler);

/**
 * Raise signal
 */
void raise_signal(int signal);

/**
 * Call signal handler
 */
void call_signal_handler(int signal);

// ============================================================================
// Pure Call Handling
// ============================================================================

/**
 * Pure virtual call handler
 */
[[noreturn]] void pure_call_handler();

/**
 * Set pure call handler
 */
void set_pure_call_handler(void (*handler)());

/**
 * Get pure call handler
 */
void (*get_pure_call_handler())();

// ============================================================================
// New Handler
// ============================================================================

/**
 * New handler function type
 */
using NewHandler = int(*)(size_t);

/**
 * Set new handler
 */
NewHandler set_new_handler(NewHandler handler);

/**
 * Get new handler
 */
NewHandler get_new_handler();

/**
 * Set new mode
 */
int set_new_mode(int mode);

/**
 * Get new mode
 */
int get_new_mode();

// ============================================================================
// Memory Management
// ============================================================================

/**
 * Allocate memory
 */
void* allocate_memory(size_t size);

/**
 * Free memory
 */
void free_memory(void* ptr);

/**
 * Reallocate memory
 */
void* reallocate_memory(void* ptr, size_t new_size);

/**
 * Get memory size
 */
size_t get_memory_size(const void* ptr);

/**
 * Allocate aligned memory
 */
void* allocate_aligned_memory(size_t size, size_t alignment);

/**
 * Free aligned memory
 */
void free_aligned_memory(void* ptr);

/**
 * Allocate zeroed memory
 */
void* allocate_zeroed_memory(size_t count, size_t size);

/**
 * Allocate copied memory
 */
void* allocate_copied_memory(const void* ptr, size_t size);

// ============================================================================
// String Management
// ============================================================================

/**
 * Duplicate string
 */
char* duplicate_string(const char* str);

/**
 * Duplicate wide string
 */
wchar_t* duplicate_wstring(const wchar_t* str);

/**
 * Duplicate string with length
 */
char* duplicate_string_n(const char* str, size_t length);

/**
 * Duplicate wide string with length
 */
wchar_t* duplicate_wstring_n(const wchar_t* str, size_t length);

/**
 * Concatenate strings
 */
char* concatenate_strings(const char* str1, const char* str2);

/**
 * Concatenate wide strings
 */
wchar_t* concatenate_wstrings(const wchar_t* str1, const wchar_t* str2);

// ============================================================================
// Wide String Conversion
// ============================================================================

/**
 * Wide to multi-byte
 */
int wide_to_multi_byte(const wchar_t* wstr, int wstr_length, char* str, int str_length);

/**
 * Multi-byte to wide
 */
int multi_byte_to_wide(const char* str, int str_length, wchar_t* wstr, int wstr_length);

/**
 * Wide to multi-byte with code page
 */
int wide_to_multi_byte_cp(uint32_t code_page, const wchar_t* wstr, int wstr_length,
                           char* str, int str_length);

/**
 * Multi-byte to wide with code page
 */
int multi_byte_to_wide_cp(uint32_t code_page, const char* str, int str_length,
                           wchar_t* wstr, int wstr_length);

// ============================================================================
// Locale-dependent String Comparison
// ============================================================================

/**
 * Compare strings with locale
 */
int compare_string_lcid(uint32_t lcid, const char* str1, int length1, const char* str2, int length2);

/**
 * Compare wide strings with locale
 */
int compare_wstring_lcid(uint32_t lcid, const wchar_t* str1, int length1,
                          const wchar_t* str2, int length2);

/**
 * Compare strings with code page
 */
int compare_string_cp(uint32_t code_page, const char* str1, int length1,
                       const char* str2, int length2);

/**
 * Compare wide strings with code page
 */
int compare_wstring_cp(uint32_t code_page, const wchar_t* str1, int length1,
                        const wchar_t* str2, int length2);

// ============================================================================
// Ctype Functions
// ============================================================================

/**
 * Get ctype info
 */
const unsigned short* get_ctype_info();

/**
 * Get clmap info
*/
const unsigned char* get_clmap_info();

/**
 * Get cumap info
*/
const unsigned char* get_cumap_info();

/**
 * Get ctype locale
*/
void* get_ctype_locale();

/**
 * Set ctype locale
*/
void set_ctype_locale(void* locale);

// ============================================================================
// Math Functions
// ============================================================================

/**
 * Floor function
 */
double math_floor(double value);

/**
 * Ceiling function
 */
double math_ceil(double value);

/**
 * Round function
 */
double math_round(double value);

/**
 * Truncate function
 */
double math_truncate(double value);

/**
 * Absolute value
 */
double math_abs(double value);

/**
 * Power function
 */
double math_pow(double base, double exponent);

/**
 * Square root
 */
double math_sqrt(double value);

/**
 * Logarithm (natural)
 */
double math_log(double value);

/**
 * Logarithm (base 10)
 */
double math_log10(double value);

/**
 * Exponent
 */
double math_exp(double value);

/**
 * Sine
 */
double math_sin(double value);

/**
 * Cosine
 */
double math_cos(double value);

/**
 * Tangent
 */
double math_tan(double value);

/**
 * Arcsine
 */
double math_asin(double value);

/**
 * Arccosine
 */
double math_acos(double value);

/**
 * Arctangent
 */
double math_atan(double value);

/**
 * Arctangent2
 */
double math_atan2(double y, double x);

/**
 * Floating point classify
 */
int math_fpclassify(double value);

/**
 * Is finite
 */
int math_isfinite(double value);

/**
 * Is infinite
 */
int math_isinf(double value);

/**
 * Is NaN
 */
int math_isnan(double value);

/**
 * Is normal
 */
int math_isnormal(double value);

// ============================================================================
// Random Number Generation
// ============================================================================

/**
 * Seed random number generator
 */
void random_seed(uint32_t seed);

/**
 * Generate random number
 */
uint32_t random_generate();

/**
 * Generate random number in range
 */
uint32_t random_generate_range(uint32_t min, uint32_t max);

/**
 * Generate random double
 */
double random_generate_double();

// ============================================================================
// Environment
// ============================================================================

/**
 * Get environment variable
 */
wchar_t* get_environment_variable(const wchar_t* name);

/**
 * Set environment variable
 */
bool set_environment_variable(const wchar_t* name, const wchar_t* value);

/**
 * Get environment strings
 */
wchar_t** get_environment_strings();

/**
 * Free environment strings
 */
bool free_environment_strings(wchar_t** strings);

/**
 * Get startup info
 */
void get_startup_info(void* startup_info);

// ============================================================================
// Console
// ============================================================================

/**
 * Ensure console output initialized
 */
bool ensure_console_output();

/**
 * Write console
 */
bool write_console(HANDLE console, const void* buffer, uint32_t length, uint32_t* written);

/**
 * Read console
 */
bool read_console(HANDLE console, void* buffer, uint32_t length, uint32_t* read);

/**
 * Get console mode
 */
bool get_console_mode(HANDLE console, uint32_t* mode);

/**
 * Set console mode
 */
bool set_console_mode(HANDLE console, uint32_t mode);

/**
 * Get console output CP
 */
uint32_t get_console_output_cp();

/**
 * Set console output CP
 */
bool set_console_output_cp(uint32_t code_page);

/**
 * Get console CP
 */
uint32_t get_console_cp();

/**
 * Set console CP
 */
bool set_console_cp(uint32_t code_page);

// ============================================================================
// Standard I/O
// ============================================================================

/**
 * Standard output handle
 */
HANDLE get_std_handle(uint32_t std_handle);

/**
 * Set std handle
 */
bool set_std_handle(uint32_t std_handle, HANDLE handle);

/**
 * Get std handle number
 */
int get_std_handle_number(HANDLE handle);

/**
 * Write file
 */
bool write_file(HANDLE file, const void* buffer, uint32_t length, uint32_t* written,
                void* overlapped);

/**
 * Read file
 */
bool read_file(HANDLE file, void* buffer, uint32_t length, uint32_t* read,
               void* overlapped);

/**
 * Flush file buffers
 */
bool flush_file_buffers(HANDLE file);

/**
 * Get file type
 */
uint32_t get_file_type(HANDLE file);

/**
 * Get file information by handle
 */
bool get_file_info_by_handle(HANDLE file, void* file_info);

/**
 * Get file information by handle ex
 */
bool get_file_info_by_handle_ex(HANDLE file, void* file_info);

/**
 * Set file pointer ex
 */
bool set_file_pointer_ex(HANDLE file, int64_t distance, int64_t* new_pointer,
                          uint32_t move_method);

/**
 * Lock file ex
 */
bool lock_file_ex(HANDLE file, uint32_t flags, uint32_t reserved, uint32_t length_low,
                   uint32_t length_high, void* overlapped);

/**
 * Unlock file ex
 */
bool unlock_file_ex(HANDLE file, uint32_t reserved, uint32_t length_low, uint32_t length_high,
                     void* overlapped);

/**
 * Write file ex
 */
bool write_file_ex(HANDLE file, const void* buffer, uint32_t length, void* overlapped,
                    void (*completion_routine)(uint32_t, uint32_t, void*));

/**
 * Read file ex
 */
bool read_file_ex(HANDLE file, void* buffer, uint32_t length, void* overlapped,
                   void (*completion_routine)(uint32_t, uint32_t, void*));

} // namespace crt
