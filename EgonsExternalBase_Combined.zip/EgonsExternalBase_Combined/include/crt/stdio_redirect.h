/**
 * EgonsExternalBase - CRT Stdio Redirect
 * Handles stdio redirection found in the decompilation
 */

#pragma once

#include "core/common.h"

namespace crt {

// ============================================================================
// Stdio Initialization
// ============================================================================

/**
 * Initialize stdio subsystem
 */
void stdio_init();

/**
 * Shutdown stdio subsystem
 */
void stdio_shutdown();

// ============================================================================
// Stdio Redirection
// ============================================================================

/**
 * Redirect stdin to a file
 */
bool stdio_redirect_stdin(const char* filename);

/**
 * Redirect stdout to a file
 */
bool stdio_redirect_stdout(const char* filename);

/**
 * Redirect stderr to a file
 */
bool stdio_redirect_stderr(const char* filename);

/**
 * Redirect stdout to a file (append mode)
 */
bool stdio_redirect_stdout_append(const char* filename);

/**
 * Restore original stdin
 */
void stdio_restore_stdin();

/**
 * Restore original stdout
 */
void stdio_restore_stdout();

/**
 * Restore original stderr
 */
void stdio_restore_stderr();

// ============================================================================
// Console Output
// ============================================================================

/**
 * Print message to console
 */
int console_print(const char* message);

/**
 * Print formatted message to console
 */
int console_print_format(const char* format, ...);

/**
 * Print error message to console
 */
int console_print_error(const char* message);

/**
 * Print formatted error message to console
 */
int console_print_error_format(const char* format, ...);

// ============================================================================
// Console Input
// ============================================================================

/**
 * Read line from console
 */
char* console_read_line(char* buffer, int buffer_size);

/**
 * Read character from console
 */
int console_read_char();

// ============================================================================
// File I/O
// ============================================================================

/**
 * Open file
 */
FILE* file_open(const char* filename, const char* mode);

/**
 * Close file
 */
void file_close(FILE* file);

/**
 * Read from file
 */
size_t file_read(void* buffer, size_t size, size_t count, FILE* file);

/**
 * Write to file
 */
size_t file_write(const void* buffer, size_t size, size_t count, FILE* file);

/**
 * Seek in file
 */
int file_seek(FILE* file, long offset, int origin);

/**
 * Get current position in file
 */
long file_tell(FILE* file);

/**
 * Flush file buffers
 */
int file_flush(FILE* file);

/**
 * Check end-of-file
 */
int file_eof(FILE* file);

/**
 * Check file error
 */
int file_error(FILE* file);

/**
 * Clear file error
 */
void file_clear_error(FILE* file);

// ============================================================================
// Formatted I/O
// ============================================================================

/**
 * Format string
 */
int format_string(char* buffer, size_t buffer_size, const char* format, ...);

/**
 * Format string with va_list
 */
int format_string_v(char* buffer, size_t buffer_size, const char* format, va_list args);

/**
 * Parse formatted string
 */
int parse_string(const char* buffer, const char* format, ...);

// ============================================================================
// Character Classification
// ============================================================================

int char_is_alpha(int ch);
int char_is_digit(int ch);
int char_is_alphanumeric(int ch);
int char_is_space(int ch);
int char_is_printable(int ch);
int char_is_upper(int ch);
int char_is_lower(int ch);
int char_to_upper(int ch);
int char_to_lower(int ch);

// ============================================================================
// Conversion Functions
// ============================================================================

int string_to_int(const char* str);
long string_to_long(const char* str);
long long string_to_long_long(const char* str);
unsigned long string_to_unsigned_long(const char* str);
unsigned long long string_to_unsigned_long_long(const char* str);
float string_to_float(const char* str);
double string_to_double(const char* str);
long double string_to_long_double(const char* str);

// ============================================================================
// Buffer Operations
// ============================================================================

void* buffer_copy(void* dest, const void* src, size_t count);
void* buffer_move(void* dest, const void* src, size_t count);
void* buffer_set(void* dest, int value, size_t count);
int buffer_compare(const void* buf1, const void* buf2, size_t count);
const void* buffer_find(const void* buf, int value, size_t count);

} // namespace crt
