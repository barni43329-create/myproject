/**
 * EgonsExternalBase - Windows API Wrapper
 * Encapsulates Windows API calls found in the decompilation
 */

#pragma once

#include "core/common.h"

#if PLATFORM_WINDOWS

namespace platform {

// ============================================================================
// Process and Thread Management
// ============================================================================

/**
 * Get current process handle
 */
HANDLE process_get_current();

/**
 * Get current process ID
 */
uint32_t process_get_id();

/**
 * Get current thread ID
 */
uint32_t thread_get_id();

/**
 * Create a new process
 */
bool process_create(
    const wchar_t* application_name,
    const wchar_t* command_line,
    HANDLE* process_handle,
    HANDLE* thread_handle
);

/**
 * Terminate a process
 */
bool process_terminate(HANDLE process, uint32_t exit_code);

/**
 * Get module handle by name
 */
HMODULE module_get_handle(const wchar_t* module_name);

/**
 * Get procedure address from module
 */
FARPROC module_get_proc(HMODULE module, const char* proc_name);

/**
 * Get module file path
 */
bool module_get_filename(HMODULE module, wchar_t* buffer, uint32_t buffer_size);

// ============================================================================
// File System Operations
// ============================================================================

/**
 * Create or open a file
 */
HANDLE file_create(
    const wchar_t* path,
    uint32_t desired_access,
    uint32_t share_mode,
    uint32_t creation_disposition,
    uint32_t flags
);

/**
 * Close a file handle
 */
void file_close(HANDLE file);

/**
 * Read from file
 */
bool file_read(HANDLE file, void* buffer, uint32_t bytes_to_read, uint32_t* bytes_read);

/**
 * Write to file
 */
bool file_write(HANDLE file, const void* buffer, uint32_t bytes_to_write, uint32_t* bytes_written);

/**
 * Get file size
 */
uint64_t file_get_size(HANDLE file);

/**
 * Set file pointer position
 */
int64_t file_set_pointer(HANDLE file, int64_t distance, uint32_t move_method);

/**
 * Delete a file
 */
bool file_delete(const wchar_t* path);

/**
 * Check if file exists
 */
bool file_exists(const wchar_t* path);

/**
 * Find first file in directory search
 */
HANDLE file_find_first(const wchar_t* path, WIN32_FIND_DATAW* find_data);

/**
 * Find next file in directory search
 */
bool file_find_next(HANDLE find_handle, WIN32_FIND_DATAW* find_data);

/**
 * Close find handle
 */
void file_find_close(HANDLE find_handle);

// ============================================================================
// Registry Operations
// ============================================================================

/**
 * Open registry key
 */
bool registry_open(HKEY parent, const wchar_t* subkey, uint32_t options, HKEY* result);

/**
 * Close registry key
 */
void registry_close(HKEY key);

/**
 * Read registry string value
 */
bool registry_read_string(HKEY key, const wchar_t* value_name, wchar_t* buffer, uint32_t buffer_size);

/**
 * Read registry DWORD value
 */
bool registry_read_dword(HKEY key, const wchar_t* value_name, uint32_t* value);

/**
 * Write registry string value
 */
bool registry_write_string(HKEY key, const wchar_t* value_name, const wchar_t* value);

/**
 * Write registry DWORD value
 */
bool registry_write_dword(HKEY key, const wchar_t* value_name, uint32_t value);

// ============================================================================
// Window Management
// ============================================================================

/**
 * Register window class
 */
ATOM window_register_class(const WNDCLASSEXW* window_class);

/**
 * Create window
 */
HWND window_create(
    const wchar_t* class_name,
    const wchar_t* window_name,
    uint32_t style,
    int x, int y, int width, int height,
    HWND parent,
    HMENU menu,
    HINSTANCE instance
);

/**
 * Destroy window
 */
bool window_destroy(HWND window);

/**
 * Show window
 */
bool window_show(HWND window, int show_command);

/**
 * Update window
 */
bool window_update(HWND window);

/**
 * Get message from queue
 */
bool window_get_message(MSG* msg, HWND window, uint32_t filter_min, uint32_t filter_max);

/**
 * Translate message
 */
bool window_translate_message(const MSG* msg);

/**
 * Dispatch message */
LRESULT window_dispatch_message(const MSG* msg);

/**
 * Send message to window
 */
LRESULT window_send_message(HWND window, uint32_t msg, WPARAM wparam, LPARAM lparam);

/**
 * Post message to window
 */
bool window_post_message(HWND window, uint32_t msg, WPARAM wparam, LPARAM lparam);

/**
 * Post quit message
 */
void window_post_quit(int exit_code);

/**
 * DefWindowProc wrapper
 */
LRESULT window_def_proc(HWND window, uint32_t msg, WPARAM wparam, LPARAM lparam);

/**
 * Get window text
 */
int window_get_text(HWND window, wchar_t* buffer, int max_count);

/**
 * Set window text
 */
bool window_set_text(HWND window, const wchar_t* text);

/**
 * Get window rectangle
 */
bool window_get_rect(HWND window, RECT* rect);

/**
 * Set window position
 */
bool window_set_pos(HWND window, HWND insert_after, int x, int y, int cx, int cy, uint32_t flags);

/**
 * Get client rectangle
 */
bool window_get_client_rect(HWND window, RECT* rect);

/**
 * Invalidate window region
 */
bool window_invalidate(HWND window, const RECT* rect, bool erase);

/**
 * Begin paint
 */
HDC window_begin_paint(HWND window, PAINTSTRUCT* paint);

/**
 * End paint
 */
bool window_end_paint(HWND window, const PAINTSTRUCT* paint);

// ============================================================================
// Device Context Operations
// ============================================================================

/**
 * Create compatible DC
 */
HDC dc_create_compatible(HDC dc);

/**
 * Delete DC
 */
bool dc_delete(HDC dc);

/**
 * Select object into DC
 */
HGDIOBJ dc_select_object(HDC dc, HGDIOBJ object);

/**
 * Create solid brush
 */
HBRUSH brush_create_solid(uint32_t color);

/**
 * Delete GDI object
 */
bool gdi_delete_object(HGDIOBJ object);

/**
 * Create font
 */
HFONT font_create(int height, int width, int escapement, int orientation,
                  int weight, bool italic, bool underline, bool strike_out,
                  const wchar_t* face_name);

/**
 * Text out
 */
bool dc_text_out(HDC dc, int x, int y, const wchar_t* text, int length);

/**
 * Get text extent
 */
bool dc_get_text_extent(HDC dc, const wchar_t* text, int length, SIZE* size);

// ============================================================================
// Resource Management
// ============================================================================

/**
 * Find resource
 */
HRSRC resource_find(HMODULE module, const wchar_t* name, const wchar_t* type);

/**
 * Load resource
 */
HGLOBAL resource_load(HMODULE module, HRSRC resource);

/**
 * Lock resource pointer
 */
void* resource_lock(HGLOBAL resource);

/**
 * Get resource size
 */
uint32_t resource_size(HMODULE module, HRSRC resource);

/**
 * Load string from resources
 */
int resource_load_string(HMODULE module, uint32_t id, wchar_t* buffer, int buffer_size);

// ============================================================================
// Clipboard Operations
// ============================================================================

/**
 * Open clipboard
 */
bool clipboard_open(HWND window);

/**
 * Close clipboard
 */
bool clipboard_close();

/**
 * Set clipboard data
 */
bool clipboard_set_data(uint32_t format, HANDLE data);

/**
 * Get clipboard data
 */
HANDLE clipboard_get_data(uint32_t format);

/**
 * Empty clipboard
 */
bool clipboard_empty();

// ============================================================================
// System Information
// ============================================================================

/**
 * Get system directory
 */
uint32_t system_get_directory(wchar_t* buffer, uint32_t size);

/**
 * Get Windows directory
 */
uint32_t system_get_windows_directory(wchar_t* buffer, uint32_t size);

/**
 * Get computer name
 */
bool system_get_computer_name(wchar_t* buffer, uint32_t* size);

/**
 * Get user name
 */
bool system_get_user_name(wchar_t* buffer, uint32_t* size);

/**
 * Get version info
 */
uint32_t system_get_version();

/**
 * Get system metrics
 */
int system_get_metrics(int index);

/**
 * Get tick count (milliseconds since boot)
 */
uint64_t system_get_tick_count();

/**
 * Get high-resolution performance counter
 */
int64_t system_get_performance_counter();

/**
 * Get performance counter frequency
 */
int64_t system_get_performance_frequency();

// ============================================================================
// Time Functions
// ============================================================================

/**
 * Get local time
 */
void time_get_local(SYSTEMTIME* time);

/**
 * Get system time (UTC)
 */
void time_get_system(SYSTEMTIME* time);

/**
 * Convert system time to file time
 */
bool time_system_to_file(const SYSTEMTIME* st, FILETIME* ft);

/**
 * Convert file time to system time
 */
bool time_file_to_system(const FILETIME* ft, SYSTEMTIME* st);

/**
 * Get timezone information
 */
uint32_t time_get_timezone(TIME_ZONE_INFORMATION* tz_info);

// ============================================================================
// Synchronization
// ============================================================================

/**
 * Initialize critical section
 */
void critical_section_init(CRITICAL_SECTION* cs);

/**
 * Enter critical section
 */
void critical_section_enter(CRITICAL_SECTION* cs);

/**
 * Leave critical section
 */
void critical_section_leave(CRITICAL_SECTION* cs);

/**
 * Try enter critical section
 */
bool critical_section_try_enter(CRITICAL_SECTION* cs);

/**
 * Delete critical section
 */
void critical_section_delete(CRITICAL_SECTION* cs);

/**
 * Initialize SRW lock
 */
void srw_lock_init(SRWLOCK* lock);

/**
 * Acquire SRW lock exclusive
 */
void srw_lock_acquire_exclusive(SRWLOCK* lock);

/**
 * Release SRW lock exclusive
 */
void srw_lock_release_exclusive(SRWLOCK* lock);

/**
 * Acquire SRW lock shared
 */
void srw_lock_acquire_shared(SRWLOCK* lock);

/**
 * Release SRW lock shared
 */
void srw_lock_release_shared(SRWLOCK* lock);

// ============================================================================
// Socket Operations
// ============================================================================

/**
 * Initialize Winsock
 */
bool socket_init(uint16_t version_requested);

/**
 * Cleanup Winsock
 */
void socket_cleanup();

/**
 * Create socket
 */
uint64_t socket_create(int address_family, int socket_type, int protocol);

/**
 * Close socket
 */
int socket_close(uint64_t socket);

/**
 * Connect socket
 */
int socket_connect(uint64_t socket, const sockaddr* address, int address_length);

/**
 * Send data
 */
int socket_send(uint64_t socket, const char* buffer, int length, int flags);

/**
 * Receive data
 */
int socket_recv(uint64_t socket, char* buffer, int length, int flags);

/**
 * Bind socket
 */
int socket_bind(uint64_t socket, const sockaddr* address, int address_length);

/**
 * Listen on socket
 */
int socket_listen(uint64_t socket, int backlog);

/**
 * Accept connection
 */
uint64_t socket_accept(uint64_t socket, sockaddr* address, int* address_length);

/**
 * Set socket option
 */
int socket_set_option(uint64_t socket, int level, int option_name, const char* option_value, int option_length);

/**
 * Get socket option
 */
int socket_get_option(uint64_t socket, int level, int option_name, char* option_value, int* option_length);

/**
 * Get hostname
 */
int socket_get_hostname(char* name, int name_length);

/**
 * Get address info
 */
int socket_get_address_info(const char* node_name, const char* service_name,
                            const addrinfo* hints, addrinfo** result);

/**
 * Free address info
 */
void socket_free_address_info(addrinfo* info);

// ============================================================================
// Debugging
// ============================================================================

/**
 * Output debug string
 */
void debug_output(const wchar_t* string);

/**
 * Is debugger present
 */
bool debug_is_present();

/**
 * Break point
 */
void debug_break();

/**
 * Get current thread ID for debugging
 */
uint32_t debug_get_thread_id();

/**
 * Get current process ID for debugging
 */
uint32_t debug_get_process_id();

// ============================================================================
// Library Loading
// ============================================================================

/**
 * Load library
 */
HMODULE library_load(const wchar_t* filename);

/**
 * Load library with flags
 */
HMODULE library_load_ex(const wchar_t* filename, HANDLE file, uint32_t flags);

/**
 * Free library
 */
bool library_free(HMODULE module);

/**
 * Get procedure address
 */
FARPROC library_get_proc(HMODULE module, const char* proc_name);

// ============================================================================
// Memory-Mapped Files
// ============================================================================

/**
 * Create file mapping
 */
HANDLE mapping_create(HANDLE file, uint32_t protect, uint64_t maximum_size, const wchar_t* name);

/**
 * Map view of file
 */
void* mapping_map(HANDLE mapping, uint32_t desired_access, uint64_t file_offset, size_t number_of_bytes);

/**
 * Unmap view of file
 */
bool mapping_unmap(const void* address);

/**
 * Close mapping handle
 */
void mapping_close(HANDLE mapping);

// ============================================================================
// Dynamic Loading Helpers
// ============================================================================

/**
 * Get module handle of calling module
 */
HMODULE get_caller_module();

/**
 * Get export address by ordinal
 */
FARPROC get_export_by_ordinal(HMODULE module, uint16_t ordinal);

/**
 * Get export address by name hash
 */
FARPROC get_export_by_hash(HMODULE module, uint32_t name_hash);

} // namespace platform

#endif // PLATFORM_WINDOWS
