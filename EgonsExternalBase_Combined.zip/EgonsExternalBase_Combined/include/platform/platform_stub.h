/**
 * EgonsExternalBase - Platform Stub (Linux/macOS)
 * Provides Windows-like types and functions for non-Windows platforms
 */

#pragma once

#include "core/common.h"

#if !PLATFORM_WINDOWS

// ============================================================================
// Basic Windows Types
// ============================================================================

using LONG      = int32_t;
using DWORD     = uint32_t;
using WORD      = uint16_t;
using BYTE      = uint8_t;
using CHAR      = char;
using WCHAR     = wchar_t;
using UINT      = uint32_t;
using INT       = int;
using BOOL      = int;
using HANDLE    = void*;
using PVOID     = void*;
using LPVOID    = void*;
using LPCVOID   = const void*;
using LPSTR     = char*;
using LPCSTR    = const char*;
using LPWSTR    = wchar_t*;
using LPCWSTR   = const wchar_t*;
using LPBOOL    = BOOL*;
using LPDWORD   = DWORD*;
using PDWORD    = DWORD*;
using PBYTE     = BYTE*;
using LPBYTE    = BYTE*;
using WPARAM    = uintptr_t;
using LPARAM    = intptr_t;
using LRESULT   = intptr_t;
using ATOM      = uint16_t;
using HINSTANCE = void*;
using HMODULE   = void*;
using HWND      = void*;
using HICON     = void*;
using HCURSOR   = void*;
using HBRUSH    = void*;
using HDC       = void*;
using HFONT     = void*;
using HGDIOBJ   = void*;
using HMENU     = void*;
using HKEY      = void*;
using HGLOBAL   = void*;
using HLOCAL    = void*;
using FARPROC   = void(*)();
using COLORREF  = uint32_t;
using HRESULT   = int32_t;
using LCID      = uint32_t;
using LCTYPE    = uint32_t;
using MMRESULT  = uint32_t;
using ULONGLONG = uint64_t;
using LONGLONG  = int64_t;
using BOOLEAN   = uint8_t;
using SHORT     = int16_t;
using SIZE_T    = size_t;
using ULONG_PTR = uintptr_t;
using DWORD_PTR = uintptr_t;
using LONG_PTR  = intptr_t;
using UINT_PTR  = uintptr_t;
using INT_PTR   = intptr_t;

// ============================================================================
// Constants
// ============================================================================

constexpr BOOL TRUE  = 1;
constexpr BOOL FALSE = 0;
constexpr HANDLE INVALID_HANDLE_VALUE = reinterpret_cast<HANDLE>(-1);

// ============================================================================
// Structures
// ============================================================================

struct GUID {
    uint32_t Data1;
    uint16_t Data2;
    uint16_t Data3;
    uint8_t  Data4[8];
};

struct POINT { LONG x, y; };
struct RECT  { LONG left, top, right, bottom; };
struct SIZE  { LONG cx, cy; };

struct FILETIME {
    DWORD dwLowDateTime;
    DWORD dwHighDateTime;
};

struct SYSTEMTIME {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek;
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
};

struct OVERLAPPED {
    ULONG_PTR Internal;
    ULONG_PTR InternalHigh;
    union {
        struct {
            DWORD Offset;
            DWORD OffsetHigh;
        };
        PVOID Pointer;
    };
    HANDLE hEvent;
};

struct CRITICAL_SECTION { /* opaque */ };

struct SRWLOCK { /* opaque */ };

struct MSG {
    HWND   hwnd;
    UINT   message;
    WPARAM wParam;
    LPARAM lParam;
    DWORD  time;
    POINT  pt;
};

struct PAINTSTRUCT {
    HDC  hdc;
    BOOL fErase;
    RECT rcPaint;
    BOOL fRestore;
    BOOL fIncUpdate;
    BYTE rgbReserved[32];
};

struct STARTUPINFOW {
    DWORD  cb;
    LPWSTR lpReserved;
    LPWSTR lpDesktop;
    LPWSTR lpTitle;
    DWORD  dwX;
    DWORD  dwY;
    DWORD  dwXSize;
    DWORD  dwYSize;
    DWORD  dwXCountChars;
    DWORD  dwYCountChars;
    DWORD  dwFillAttribute;
    DWORD  dwFlags;
    WORD   wShowWindow;
    WORD   cbReserved2;
    LPBYTE lpReserved2;
    HANDLE hStdInput;
    HANDLE hStdOutput;
    HANDLE hStdError;
};

struct PROCESS_INFORMATION {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD  dwProcessId;
    DWORD  dwThreadId;
};

struct SECURITY_ATTRIBUTES {
    DWORD  nLength;
    LPVOID lpSecurityDescriptor;
    BOOL   bInheritHandle;
};

struct WIN32_FIND_DATAW {
    DWORD    dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD    nFileSizeHigh;
    DWORD    nFileSizeLow;
    DWORD    dwReserved0;
    DWORD    dwReserved1;
    WCHAR    cFileName[260];
    WCHAR    cAlternateFileName[14];
};

struct WNDCLASSEXW {
    UINT      cbSize;
    UINT      style;
    FARPROC   lpfnWndProc;
    int       cbClsExtra;
    int       cbWndExtra;
    HINSTANCE hInstance;
    HICON     hIcon;
    HCURSOR   hCursor;
    HBRUSH    hbrBackground;
    LPCWSTR   lpszMenuName;
    LPCWSTR   lpszClassName;
    HICON     hIconSm;
};

struct LARGE_INTEGER {
    union {
        struct {
            DWORD LowPart;
            LONG  HighPart;
        };
        LONGLONG QuadPart;
    };
};

#endif // !PLATFORM_WINDOWS
