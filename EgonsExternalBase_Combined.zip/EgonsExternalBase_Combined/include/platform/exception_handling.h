/**
 * EgonsExternalBase - Exception Handling
 * Encapsulates Windows SEH and C++ exception handling
 */

#pragma once

#include "core/common.h"

#if PLATFORM_WINDOWS

namespace platform {

// ============================================================================
// Exception Handling Structures
// ============================================================================

/**
 * Exception handler context
 */
struct ExceptionContext {
    EXCEPTION_RECORD record;
    CONTEXT context;
    uintptr_t frame_pointer;
    uintptr_t return_address;
};

/**
 * Exception filter function type
 */
using ExceptionFilter = int(*)(EXCEPTION_POINTERS* exception_info);

/**
 * Exception handler function type
 */
using ExceptionHandler = void(*)(EXCEPTION_RECORD* record, void* context);

/**
 * Termination handler function type
 */
using TerminationHandler = void(*)(void);

/**
 * VEH handler function type
 */
using VectoredHandler = LONG(*)(EXCEPTION_POINTERS* exception_info);

// ============================================================================
// Structured Exception Handling (SEH)
// ============================================================================

/**
 * Register vectored exception handler
 */
void* exception_register_vectored(Vectored_handler handler, bool first_handler);

/**
 * Remove vectored exception handler
 */
uint32_t exception_remove_vectored(void* handle);

/**
 * Set unhandled exception filter
 */
void exception_set_unhandled_filter(ExceptionFilter filter);

/**
 * Raise exception
 */
void exception_raise(uint32_t code, uint32_t flags, uint32_t argument_count,
                     const uintptr_t* arguments);

/**
 * Continue execution after exception
 */
void exception_continue();

/**
 * Continue execution with search
 */
void exception_continue_search();

// ============================================================================
// C++ Exception Handling
// ============================================================================

/**
 * Throw C++ exception
 */
void cpp_throw(uint32_t code, void* exception_object);

/**
 * Get exception code
 */
uint32_t cpp_get_exception_code(const EXCEPTION_RECORD* record);

/**
 * Check if exception is C++ exception
 */
bool cpp_is_cpp_exception(const EXCEPTION_RECORD* record);

/**
 * Get exception object pointer
 */
void* cpp_get_exception_object(const EXCEPTION_RECORD* record);

/**
 * Set exception parameters
 */
void cpp_set_exception_params(uint32_t magic, void* object, void* info);

/**
 * Begin C++ try block
 */
void cpp_try_begin();

/**
 * End C++ try block
 */
void cpp_try_end();

/**
 * Catch C++ exception
 */
void cpp_catch(void* exception_type);

// ============================================================================
// Guard Security
// ============================================================================

/**
 * Validate security cookie (buffer overflow detection)
 */
void guard_validate_cookie(uintptr_t cookie);

/**
 * Check security cookie
 */
uintptr_t guard_check_cookie(uintptr_t cookie);

/**
 * Setup security cookie
 */
uintptr_t guard_setup_cookie();

/**
 * Report GS failure
 */
void guard_report_failure();

// ============================================================================
// Stack Checking
// ============================================================================

/**
 * Probe stack space
 */
void stack_probe(uintptr_t frame);

/**
 * Probe stack space (all)
 */
void stack_probe_all(uintptr_t frame);

/**
 * Restore stack
 */
void stack_restore(uintptr_t frame);

// ============================================================================
// Runtime Function Lookup
// ============================================================================

/**
 * Lookup runtime function entry
 */
PRUNTIME_FUNCTION runtime_lookup_function(uint64_t control_pc, void* context);

/**
 * Virtual unwind
 */
void* runtime_virtual_unwind(uint64_t handler_type, uint64_t image_base,
                              uint64_t control_pc, PRUNTIME_FUNCTION function_entry,
                              CONTEXT* context);

/**
 * Unwind frame
 */
void runtime_unwind_frame(void* frame, void* target_ip, CONTEXT* context,
                          void* history_table);

// ============================================================================
// Exception Dispatcher
// ============================================================================

/**
 * Dispatch exception to appropriate handler
 */
void exception_dispatch(EXCEPTION_RECORD* record, CONTEXT* context);

/**
 * Execute exception handler
 */
void exception_execute_handler(EXCEPTION_RECORD* record, void* handler, CONTEXT* context);

/**
 * Execute termination handlers
 */
void exception_execute_terminators();

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Get exception string description
 */
const char* exception_get_string(uint32_t code);

/**
 * Format exception record
 */
void exception_format_record(const EXCEPTION_RECORD* record, char* buffer, size_t buffer_size);

/**
 * Log exception
 */
void exception_log(const EXCEPTION_RECORD* record);

/**
 * Check if exception is continuable
 */
bool exception_is_continuable(const EXCEPTION_RECORD* record);

/**
 * Get exception address
 */
void* exception_get_address(const EXCEPTION_RECORD* record);

/**
 * Set exception address
 */
void exception_set_address(EXCEPTION_RECORD* record, void* address);

/**
 * Add exception parameter
 */
void exception_add_parameter(EXCEPTION_RECORD* record, uintptr_t parameter);

/**
 * Get exception parameter
 */
uintptr_t exception_get_parameter(const EXCEPTION_RECORD* record, uint32_t index);

} // namespace platform

#endif // PLATFORM_WINDOWS
