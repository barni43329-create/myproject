/**
 * EgonsExternalBase - Deobfuscated and Restructured
 * Common type definitions and platform includes
 *
 * Original: Ghidra decompilation of Windows x64 binary
 * Restructured: Modern C++17 project
 */

#pragma once

// ============================================================================
// Standard Includes
// ============================================================================
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cstdarg>
#include <cctype>
#include <cmath>
#include <ctime>
#include <cerrno>
#include <cassert>
#include <algorithm>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <set>
#include <list>
#include <memory>
#include <functional>
#include <mutex>
#include <atomic>

// ============================================================================
// Platform Detection
// ============================================================================
#if defined(_WIN32) || defined(_WIN64)
    #define PLATFORM_WINDOWS 1
    #ifndef WIN32_LEAN_AND_MEAN
        #define WIN32_LEAN_AND_MEAN
    #endif
    #ifndef NOMINMAX
        #define NOMINMAX
    #endif
    #include <windows.h>
    #include <winbase.h>
    #include <winnt.h>
    #include <winuser.h>
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <shellapi.h>
    #include <shlobj.h>
    #include <dbghelp.h>
    #include <tlhelp32.h>
    #include <psapi.h>
    #include <iphlpapi.h>
#else
    #define PLATFORM_WINDOWS 0
    #include "platform/platform_stub.h"
#endif

// ============================================================================
// Ghidra Type Mappings (deobfuscated)
// ============================================================================
using undefined  = uint8_t;
using undefined1 = uint8_t;
using undefined2 = uint16_t;
using undefined4 = uint32_t;
using undefined8 = uint64_t;
using byte       = uint8_t;
using word       = uint16_t;
using dword      = uint32_t;
using qword      = uint64_t;
using uchar      = uint8_t;
using ushort     = uint16_t;
using uint       = uint32_t;
using ulong      = uint32_t;
using ulonglong  = uint64_t;
using bool8      = uint8_t;
using longlong   = int64_t;

// Windows type aliases using standard equivalents
using GUID_       = ::GUID;
using LONG        = ::LONG;
using DWORD       = ::DWORD;
using WORD        = ::WORD;
using BYTE        = ::BYTE;
using CHAR        = char;
using WCHAR       = wchar_t;
using UINT        = ::UINT;
using INT         = int;
using BOOL        = ::BOOL;
using HANDLE      = ::HANDLE;
using PVOID       = void*;
using LPVOID      = ::LPVOID;
using LPCVOID     = ::LPCVOID;
using LPSTR       = ::LPSTR;
using LPCSTR      = ::LPCSTR;
using LPWSTR      = ::LPWSTR;
using LPCWSTR     = ::LPCWSTR;
using LPBOOL      = ::LPBOOL;
using LPDWORD     = ::LPDWORD;
using PDWORD      = ::PDWORD;
using PBYTE       = ::PBYTE;
using LPBYTE      = ::LPBYTE;
using LPPOINT     = ::LPPOINT;
using LPRECT      = ::LPRECT;
using LPMSG       = ::LPMSG;
using LPOVERLAPPED = ::LPOVERLAPPED;
using LPSTARTUPINFOW = ::LPSTARTUPINFOW;
using LPPROCESS_INFORMATION = ::LPPROCESS_INFORMATION;
using LPSECURITY_ATTRIBUTES = ::LPSECURITY_ATTRIBUTES;
using LPFILETIME  = ::LPFILETIME;
using PLARGE_INTEGER = ::PLARGE_INTEGER;
using LPCRITICAL_SECTION = ::LPCRITICAL_SECTION;
using SIZE_T      = ::SIZE_T;
using ULONG_PTR   = ::ULONG_PTR;
using DWORD_PTR   = ::DWORD_PTR;
using LONG_PTR    = ::LONG_PTR;
using UINT_PTR    = ::UINT_PTR;
using INT_PTR     = ::INT_PTR;
using WPARAM      = ::WPARAM;
using LPARAM      = ::LPARAM;
using LRESULT     = ::LRESULT;
using ATOM        = ::ATOM;
using HINSTANCE   = ::HINSTANCE;
using HMODULE     = ::HMODULE;
using HWND        = ::HWND;
using HICON       = ::HICON;
using HCURSOR     = ::HCURSOR;
using HBRUSH      = ::HBRUSH;
using HDC         = ::HDC;
using HFONT       = ::HFONT;
using HGDIOBJ     = ::HGDIOBJ;
using HMENU       = ::HMENU;
using HKEY        = ::HKEY;
using HGLOBAL     = ::HGLOBAL;
using HLOCAL      = ::HLOCAL;
using FARPROC     = ::FARPROC;
using COLORREF    = ::COLORREF;
using HRESULT     = ::HRESULT;
using LCID        = ::LCID;
using LCTYPE      = ::LCTYPE;
using MMRESULT    = ::MMRESULT;
using ULONGLONG   = ::ULONGLONG;
using LONGLONG    = ::LONGLONG;
using BOOLEAN     = ::BOOLEAN;
using SHORT       = ::SHORT;
using FILETIME    = ::FILETIME;
using SYSTEMTIME  = ::SYSTEMTIME;
using TIME_ZONE_INFORMATION = ::TIME_ZONE_INFORMATION;

// ============================================================================
// Constants
// ============================================================================
constexpr size_t MAX_PATH_LEN = 260;
constexpr size_t MAX_ALTERNATE_PATH = 14;
constexpr uint32_t INVALID_FOURCC = 0xFFFFFFFF;
constexpr uint64_t INVALID_ADDRESS = 0xFFFFFFFFFFFFFFFFULL;

// ============================================================================
// Utility Macros
// ============================================================================
#define ALIGN_DOWN(x, align)  ((x) & ~((align) - 1))
#define ALIGN_UP(x, align)    (((x) + ((align) - 1)) & ~((align) - 1))
#define ARRAY_SIZE(arr)       (sizeof(arr) / sizeof((arr)[0]))
#define SAFE_FREE(ptr)        do { if (ptr) { free(ptr); (ptr) = nullptr; } } while(0)
#define SAFE_DELETE(ptr)      do { if (ptr) { delete (ptr); (ptr) = nullptr; } } while(0)
#define SAFE_RELEASE(ptr)     do { if (ptr) { (ptr)->Release(); (ptr) = nullptr; } } while(0)

// ============================================================================
// Memory Allocation Helpers
// ============================================================================
namespace core {

/**
 * Aligned memory allocation (replaces Ghidra's custom allocator patterns)
 */
inline void* aligned_alloc(size_t size, size_t alignment = 64) {
    void* ptr = nullptr;
#if PLATFORM_WINDOWS
    ptr = _aligned_malloc(size, alignment);
#else
    if (posix_memalign(&ptr, alignment, size) != 0) ptr = nullptr;
#endif
    return ptr;
}

inline void aligned_free(void* ptr) {
#if PLATFORM_WINDOWS
    _aligned_free(ptr);
#else
    free(ptr);
#endif
}

/**
 * Allocate memory with header for original-pointer tracking
 * (recovers the 0x27-byte header pattern from the decompilation)
 */
inline void* tracked_alloc(size_t size) {
    if (size == 0) return nullptr;
    if (size >= 0x1000) {
        // Large allocation: add header for original pointer
        size_t total = size + 0x27;
        void* raw = malloc(total);
        if (!raw) return nullptr;
        void* aligned = (void*)(((uintptr_t)raw + 0x27) & ~0x1FULL);
        ((void**)aligned)[-1] = raw;  // Store original pointer
        return aligned;
    }
    return malloc(size);
}

inline void tracked_free(void* ptr) {
    free(ptr);
}

} // namespace core
