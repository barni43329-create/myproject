/**
 * EgonsExternalBase - Memory Management
 * Replaces Ghidra's raw allocation patterns with modern C++ equivalents
 */

#pragma once

#include "core/common.h"

namespace core {

// ============================================================================
// Memory Allocation Functions
// ============================================================================

/**
 * Allocate memory block (replaces malloc_base)
 * @param size Number of bytes to allocate
 * @return Pointer to allocated memory, or nullptr on failure
 */
void* mem_alloc(size_t size);

/**
 * Free memory block (replaces free_base)
 * @param ptr Pointer to memory block to free
 */
void mem_free(void* ptr);

/**
 * Reallocate memory block (replaces realloc_base)
 * @param ptr Pointer to existing memory block
 * @param new_size New size in bytes
 * @return Pointer to reallocated memory, or nullptr on failure
 */
void* mem_realloc(void* ptr, size_t new_size);

/**
 * Get allocated memory size (replaces msize_base)
 * @param ptr Pointer to allocated memory block
 * @return Size of the allocated block, or (size_t)-1 on failure
 */
size_t mem_size(const void* ptr);

/**
 * Callocate memory (replaces calloc_base)
 * @param count Number of elements
 * @param size Size of each element
 * @return Pointer to zero-initialized memory, or nullptr on failure
 */
void* mem_calloc(size_t count, size_t size);

// ============================================================================
// String Memory Management (Small String Optimization pattern)
// ============================================================================

/**
 * Allocate string storage with small-string optimization
 * Mirrors the original's pattern of inline storage for strings < 16 chars
 */
struct StringStorage {
    static constexpr size_t SSO_THRESHOLD = 15;
    
    char* data;
    size_t length;
    size_t capacity;
    
    // SSO buffer (used when capacity <= SSO_THRESHOLD)
    char sso_buffer[16];
    
    StringStorage();
    StringStorage(const char* str);
    StringStorage(const char* str, size_t len);
    ~StringStorage();
    
    void append(const char* str, size_t len);
    void resize(size_t new_cap);
};

// ============================================================================
// Memory Utilities
// ============================================================================

/**
 * Secure zero memory (prevents compiler optimization)
 * @param ptr Pointer to memory
 * @param size Number of bytes to zero
 */
void secure_zero(void* ptr, size_t size);

/**
 * Copy memory with overlap handling
 */
void* mem_move(void* dest, const void* src, size_t count);

/**
 * Fill memory with byte pattern
 */
void* mem_fill(void* dest, uint8_t value, size_t count);

} // namespace core
