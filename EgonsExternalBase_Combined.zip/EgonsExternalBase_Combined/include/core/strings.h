/**
 * EgonsExternalBase - String Operations
 * Replaces Ghidra's decompiled string functions with modern C++ equivalents
 */

#pragma once

#include "core/common.h"

namespace core {

// ============================================================================
// String Comparison Functions
// ============================================================================

/**
 * Compare two byte strings (replaces original memcmp implementation)
 */
int str_compare(const void* buf1, const void* buf2, size_t size);

/**
 * Compare two null-terminated strings (replaces strcmp)
 */
int str_compare_nt(const char* str1, const char* str2);

/**
 * Compare two strings up to max_count characters (replaces strncmp)
 */
int str_compare_nt_n(const char* str1, const char* str2, size_t max_count);

/**
 * Case-insensitive string comparison
 */
int str_compare_no_case(const char* str1, const char* str2);

/**
 * Case-insensitive string comparison with length limit
 */
int str_compare_no_case_n(const char* str1, const char* str2, size_t max_count);

// ============================================================================
// String Copy Functions
// ============================================================================

/**
 * Copy string with length limit (replaces strncpy)
 */
char* str_copy(char* dest, const char* source, size_t count);

/**
 * Copy wide string with length limit
 */
wchar_t* wstr_copy(wchar_t* dest, const wchar_t* source, size_t count);

// ============================================================================
// String Search Functions
// ============================================================================

/**
 * Find character in string (replaces strchr with SIMD optimization)
 */
const char* str_find_char(const char* str, char ch);
char* str_find_char_mut(char* str, char ch);

/**
 * Find substring in string
 */
const char* str_find_substr(const char* str, const char* substr);

/**
 * Find last occurrence of character
 */
const char* str_find_last_char(const char* str, char ch);

// ============================================================================
// String Length Functions
// ============================================================================

/**
 * Get string length (replaces strlen)
 */
size_t str_length(const char* str);

/**
 * Get wide string length
 */
size_t wstr_length(const wchar_t* str);

/**
 * Count characters up to limit (replaces __strncnt)
 */
size_t str_count(const char* str, size_t limit);

// ============================================================================
// String Conversion Functions
// ============================================================================

/**
 * Wide string to multi-byte string conversion
 */
int wstr_to_str(const wchar_t* wstr, char* str, int str_size);

/**
 * Multi-byte string to wide string conversion
 */
int str_to_wstr(const char* str, wchar_t* wstr, int wstr_size);

/**
 * Compare wide strings
 */
int wstr_compare(const wchar_t* str1, const wchar_t* str2, size_t count);

// ============================================================================
// String Manipulation
// ============================================================================

/**
 * Concatenate strings with length limit
 */
char* str_concat(char* dest, const char* source, size_t dest_size);

/**
 * Tokenize string (thread-safe)
 */
char* str_token(char* str, const char* delimiters, char** context);

/**
 * Reverse string in place
 */
char* str_reverse(char* str);

/**
 * Convert string to uppercase
 */
char* str_to_upper(char* str);

/**
 * Convert string to lowercase
 */
char* str_to_lower(char* str);

// ============================================================================
// Formatted String Functions
// ============================================================================

/**
 * Format string with variable arguments (safe)
 */
int str_format(char* buffer, size_t buffer_size, const char* format, ...);

/**
 * Format string with va_list
 */
int str_format_v(char* buffer, size_t buffer_size, const char* format, va_list args);

/**
 * Parse formatted input
 */
int str_scan(const char* buffer, const char* format, ...);

} // namespace core
