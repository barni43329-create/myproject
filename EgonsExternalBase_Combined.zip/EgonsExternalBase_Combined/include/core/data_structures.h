/**
 * EgonsExternalBase - Data Structures
 * Replaces Ghidra's offset-based struct access with proper C++ classes
 */

#pragma once

#include "core/common.h"

namespace core {

// ============================================================================
// Hash Map (replaces unordered_map patterns from decompilation)
// ============================================================================

/**
 * FNV-1a hash function (matches the original's hash implementation)
 */
constexpr uint64_t FNV_OFFSET_BASIS = 0xcbf29ce484222325ULL;
constexpr uint64_t FNV_PRIME = 0x100000001b3ULL;

inline uint64_t fnv1a_hash(const void* data, size_t length) {
    uint64_t hash = FNV_OFFSET_BASIS;
    const uint8_t* bytes = static_cast<const uint8_t*>(data);
    for (size_t i = 0; i < length; i++) {
        hash ^= bytes[i];
        hash *= FNV_PRIME;
    }
    return hash;
}

/**
 * Generic hash map with chaining
 * Mirrors the original's bucket-based hash table implementation
 */
template<typename K, typename V>
class HashMap {
public:
    struct Node {
        K key;
        V value;
        Node* next;
        
        Node(const K& k, const V& v) : key(k), value(v), next(nullptr) {}
    };
    
    HashMap(size_t bucket_count = 64);
    ~HashMap();
    
    // Insert or update
    bool insert(const K& key, const V& value);
    
    // Find existing entry
    V* find(const K& key);
    const V* find(const K& key) const;
    
    // Remove entry
    bool remove(const K& key);
    
    // Clear all entries
    void clear();
    
    // Iteration
    template<typename Func>
    void for_each(Func func) const;
    
    size_t size() const { return m_size; }
    bool empty() const { return m_size == 0; }
    
private:
    size_t bucket_index(const K& key) const;
    void rehash(size_t new_bucket_count);
    
    Node** m_buckets;
    size_t m_bucket_count;
    size_t m_size;
    float m_max_load_factor;
};

// ============================================================================
// Dynamic Array (replaces vector patterns from decompilation)
// ============================================================================

/**
 * Dynamic array with manual memory management
 * Mirrors the original's 5-element tuple storage pattern
 */
template<typename T>
class DynamicArray {
public:
    DynamicArray();
    explicit DynamicArray(size_t initial_capacity);
    ~DynamicArray();
    
    // Element access
    T& operator[](size_t index);
    const T& operator[](size_t index) const;
    
    T& front();
    const T& front() const;
    
    T& back();
    const T& back() const;
    
    // Capacity
    size_t size() const { return m_size; }
    size_t capacity() const { return m_capacity; }
    bool empty() const { return m_size == 0; }
    
    // Modifiers
    void push_back(const T& value);
    void pop_back();
    void insert(size_t index, const T& value);
    void erase(size_t index);
    void clear();
    void reserve(size_t new_capacity);
    void resize(size_t new_size);
    
    // Raw data access
    T* data() { return m_data; }
    const T* data() const { return m_data; }
    
private:
    void grow(size_t min_capacity = 0);
    
    T* m_data;
    size_t m_size;
    size_t m_capacity;
};

// ============================================================================
// Binary Tree (replaces tree patterns from decompilation)
// ============================================================================

/**
 * Red-black tree node color
 */
enum class NodeColor : uint8_t { Red, Black };

/**
 * Binary search tree (mirrors the original's tree implementation)
 */
template<typename K, typename V>
class BinaryTree {
public:
    struct Node {
        K key;
        V value;
        NodeColor color;
        Node* left;
        Node* right;
        Node* parent;
        
        Node(const K& k, const V& v) 
            : key(k), value(v), color(NodeColor::Red),
              left(nullptr), right(nullptr), parent(nullptr) {}
    };
    
    BinaryTree();
    ~BinaryTree();
    
    // Insert or update
    bool insert(const K& key, const V& value);
    
    // Find existing entry
    V* find(const K& key);
    const V* find(const K& key) const;
    
    // Remove entry
    bool remove(const K& key);
    
    // Clear all entries
    void clear();
    
    // Iteration
    template<typename Func>
    void in_order(Func func) const;
    
    template<typename Func>
    void pre_order(Func func) const;
    
    size_t size() const { return m_size; }
    bool empty() const { return m_size == 0; }
    
private:
    void rotate_left(Node* node);
    void rotate_right(Node* node);
    void insert_fixup(Node* node);
    void delete_fixup(Node* node);
    void transplant(Node* old_node, Node* new_node);
    Node* minimum(Node* node) const;
    Node* find_node(const K& key) const;
    void destroy_tree(Node* node);
    void in_order_recursive(Node* node, auto&& func) const;
    
    Node* m_root;
    Node* m_sentinel;
    size_t m_size;
};

// ============================================================================
// Linked List (replaces list patterns from decompilation)
// ============================================================================

/**
 * Doubly-linked list
 */
template<typename T>
class LinkedList {
public:
    struct Node {
        T value;
        Node* next;
        Node* prev;
        
        Node(const T& v) : value(v), next(nullptr), prev(nullptr) {}
    };
    
    LinkedList();
    ~LinkedList();
    
    // Element access
    T& front();
    const T& front() const;
    
    T& back();
    const T& back() const;
    
    // Modifiers
    void push_front(const T& value);
    void push_back(const T& value);
    void pop_front();
    void pop_back();
    void insert(Node* pos, const T& value);
    void erase(Node* node);
    void clear();
    
    // List operations
    void splice(LinkedList& other);
    void reverse();
    void sort();
    
    size_t size() const { return m_size; }
    bool empty() const { return m_size == 0; }
    
    // Iteration
    template<typename Func>
    void for_each(Func func) const;
    
private:
    Node* m_head;
    Node* m_tail;
    size_t m_size;
};

// ============================================================================
// String Key-Value Store (specific pattern from decompilation)
// ============================================================================

/**
 * String-keyed hash map with value type erasure
 * Mirrors the original's string-based lookup tables
 */
class StringMap {
public:
    struct Entry {
        std::string key;
        void* value;
        size_t value_size;
        
        Entry(const std::string& k, void* v, size_t vs)
            : key(k), value(v), value_size(vs) {}
    };
    
    StringMap();
    ~StringMap();
    
    // Insert or update
    bool insert(const std::string& key, void* value, size_t value_size);
    
    // Find existing entry
    void* find(const std::string& key);
    const void* find(const std::string& key) const;
    
    // Remove entry
    bool remove(const std::string& key);
    
    // Clear all entries
    void clear();
    
    size_t size() const;
    bool empty() const;
    
private:
    HashMap<std::string, Entry> m_map;
};

} // namespace core

// Template implementations would go in a separate header in production
