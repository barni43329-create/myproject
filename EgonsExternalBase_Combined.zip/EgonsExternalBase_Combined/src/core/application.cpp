/**
 * EgonsExternalBase - Application Core
 * Main application logic extracted from decompilation
 */

#include "core/common.h"
#include "core/memory.h"
#include "core/strings.h"
#include "core/data_structures.h"

#include <algorithm>
#include <cstring>

// ============================================================================
// Global State (replaces scattered DAT_ variables)
// ============================================================================

namespace {

/**
 * Application state structure
 * Consolidates the many global variables from the decompilation
 */
struct ApplicationState {
    // Memory management
    void* primary_heap = nullptr;
    void* secondary_heap = nullptr;
    size_t allocation_count = 0;
    size_t total_allocated = 0;
    
    // String management
    std::mutex string_mutex;
    core::StringMap* string_table = nullptr;
    
    // Data structures
    core::HashMap<uint64_t, void*>* handle_table = nullptr;
    core::HashMap<std::string, void*>* resource_table = nullptr;
    
    // Window management
    HWND main_window = nullptr;
    HINSTANCE instance_handle = nullptr;
    int show_command = 0;
    
    // Flags
    bool initialized = false;
    bool shutdown_requested = false;
    uint32_t error_code = 0;
    
    // Time tracking
    int64_t performance_frequency = 0;
    int64_t start_time = 0;
    
    // Locale
    void* locale_info = nullptr;
    uint32_t code_page = 0;
    
    // Floating point control
    uint32_t fp_control = 0;
    
    // Thread local storage
    void* tls_data = nullptr;
    
    ApplicationState() = default;
};

// Singleton instance
ApplicationState& get_state() {
    static ApplicationState state;
    return state;
}

} // anonymous namespace

// ============================================================================
// Memory Management Implementation
// ============================================================================

namespace core {

void* mem_alloc(size_t size) {
    if (size == 0) return nullptr;
    void* ptr = std::malloc(size);
    if (ptr) {
        get_state().allocation_count++;
        get_state().total_allocated += size;
    }
    return ptr;
}

void mem_free(void* ptr) {
    if (ptr) {
        std::free(ptr);
        get_state().allocation_count--;
    }
}

void* mem_realloc(void* ptr, size_t new_size) {
    void* new_ptr = std::realloc(ptr, new_size);
    if (new_ptr && !ptr) {
        get_state().allocation_count++;
    }
    return new_ptr;
}

size_t mem_size(const void* ptr) {
    if (!ptr) return (size_t)-1;
#if PLATFORM_WINDOWS
    return _msize(const_cast<void*>(ptr));
#else
    return malloc_usable_size(const_cast<void*>(ptr));
#endif
}

void* mem_calloc(size_t count, size_t size) {
    if (count == 0 || size == 0) return nullptr;
    void* ptr = std::calloc(count, size);
    if (ptr) {
        get_state().allocation_count++;
        get_state().total_allocated += count * size;
    }
    return ptr;
}

void secure_zero(void* ptr, size_t size) {
    if (ptr && size > 0) {
        volatile unsigned char* p = static_cast<volatile unsigned char*>(ptr);
        while (size--) {
            *p++ = 0;
        }
    }
}

void* mem_move(void* dest, const void* src, size_t count) {
    return std::memmove(dest, src, count);
}

void* mem_fill(void* dest, uint8_t value, size_t count) {
    return std::memset(dest, value, count);
}

// ============================================================================
// StringStorage Implementation
// ============================================================================

StringStorage::StringStorage() : data(sso_buffer), length(0), capacity(SSO_THRESHOLD) {
    sso_buffer[0] = '\0';
}

StringStorage::StringStorage(const char* str) : StringStorage() {
    if (str) {
        size_t len = std::strlen(str);
        if (len > SSO_THRESHOLD) {
            resize(len);
        }
        std::memcpy(data, str, len);
        length = len;
        data[length] = '\0';
    }
}

StringStorage::StringStorage(const char* str, size_t len) : StringStorage() {
    if (str && len > 0) {
        if (len > SSO_THRESHOLD) {
            resize(len);
        }
        std::memcpy(data, str, len);
        length = len;
        data[length] = '\0';
    }
}

StringStorage::~StringStorage() {
    if (data != sso_buffer) {
        std::free(data);
    }
}

void StringStorage::append(const char* str, size_t len) {
    if (!str || len == 0) return;
    size_t new_length = length + len;
    if (new_length > capacity) {
        resize(new_length * 2);
    }
    std::memcpy(data + length, str, len);
    length = new_length;
    data[length] = '\0';
}

void StringStorage::resize(size_t new_cap) {
    if (new_cap <= capacity) return;
    
    size_t alloc_cap = SSO_THRESHOLD + 1;
    while (alloc_cap < new_cap) {
        alloc_cap = (alloc_cap * 3) / 2;
    }
    
    char* new_data;
    if (data == sso_buffer) {
        new_data = static_cast<char*>(std::malloc(alloc_cap));
        if (new_data) {
            std::memcpy(new_data, sso_buffer, length + 1);
        }
    } else {
        new_data = static_cast<char*>(std::realloc(data, alloc_cap));
    }
    
    if (new_data) {
        data = new_data;
        capacity = alloc_cap - 1;
    }
}

} // namespace core

// ============================================================================
// String Operations Implementation
// ============================================================================

namespace core {

int str_compare(const void* buf1, const void* buf2, size_t size) {
    return std::memcmp(buf1, buf2, size);
}

int str_compare_nt(const char* str1, const char* str2) {
    return std::strcmp(str1, str2);
}

int str_compare_nt_n(const char* str1, const char* str2, size_t max_count) {
    return std::strncmp(str1, str2, max_count);
}

int str_compare_no_case(const char* str1, const char* str2) {
#if PLATFORM_WINDOWS
    return _stricmp(str1, str2);
#else
    return strcasecmp(str1, str2);
#endif
}

int str_compare_no_case_n(const char* str1, const char* str2, size_t max_count) {
#if PLATFORM_WINDOWS
    return _strnicmp(str1, str2, max_count);
#else
    return strncasecmp(str1, str2, max_count);
#endif
}

char* str_copy(char* dest, const char* source, size_t count) {
    if (!dest || !source || count == 0) return dest;
    std::strncpy(dest, source, count);
    dest[count - 1] = '\0';
    return dest;
}

wchar_t* wstr_copy(wchar_t* dest, const wchar_t* source, size_t count) {
    if (!dest || !source || count == 0) return dest;
    std::wcsncpy(dest, source, count);
    dest[count - 1] = L'\0';
    return dest;
}

const char* str_find_char(const char* str, char ch) {
    return std::strchr(str, ch);
}

char* str_find_char_mut(char* str, char ch) {
    return std::strchr(str, ch);
}

const char* str_find_substr(const char* str, const char* substr) {
    return std::strstr(str, substr);
}

const char* str_find_last_char(const char* str, char ch) {
    return std::strrchr(str, ch);
}

size_t str_length(const char* str) {
    return std::strlen(str);
}

size_t wstr_length(const wchar_t* str) {
    return std::wcslen(str);
}

size_t str_count(const char* str, size_t limit) {
    size_t count = 0;
    if (str) {
        while (*str != '\0' && count != limit) {
            count++;
            str++;
        }
    }
    return count;
}

int wstr_to_str(const wchar_t* wstr, char* str, int str_size) {
    if (!wstr || !str || str_size <= 0) return 0;
#if PLATFORM_WINDOWS
    return WideCharToMultiByte(CP_ACP, 0, wstr, -1, str, str_size, nullptr, nullptr);
#else
    std::wcstombs(str, wstr, str_size);
    return std::strlen(str);
#endif
}

int str_to_wstr(const char* str, wchar_t* wstr, int wstr_size) {
    if (!str || !wstr || wstr_size <= 0) return 0;
#if PLATFORM_WINDOWS
    return MultiByteToWideChar(CP_ACP, 0, str, -1, wstr, wstr_size);
#else
    std::mbstowcs(wstr, str, wstr_size);
    return std::wcslen(wstr);
#endif
}

int wstr_compare(const wchar_t* str1, const wchar_t* str2, size_t count) {
    return std::wcsncmp(str1, str2, count);
}

char* str_concat(char* dest, const char* source, size_t dest_size) {
    if (!dest || !source || dest_size == 0) return dest;
    size_t dest_len = std::strlen(dest);
    size_t remaining = dest_size - dest_len - 1;
    if (remaining > 0) {
        std::strncat(dest, source, remaining);
    }
    return dest;
}

char* str_token(char* str, const char* delimiters, char** context) {
#if PLATFORM_WINDOWS
    return std::strtok_s(str, delimiters, context);
#else
    return std::strtok_r(str, delimiters, context);
#endif
}

char* str_reverse(char* str) {
    if (!str) return nullptr;
    size_t len = std::strlen(str);
    for (size_t i = 0; i < len / 2; i++) {
        std::swap(str[i], str[len - 1 - i]);
    }
    return str;
}

char* str_to_upper(char* str) {
    if (!str) return nullptr;
    for (size_t i = 0; str[i]; i++) {
        str[i] = static_cast<char>(std::toupper(static_cast<unsigned char>(str[i])));
    }
    return str;
}

char* str_to_lower(char* str) {
    if (!str) return nullptr;
    for (size_t i = 0; str[i]; i++) {
        str[i] = static_cast<char>(std::tolower(static_cast<unsigned char>(str[i])));
    }
    return str;
}

int str_format(char* buffer, size_t buffer_size, const char* format, ...) {
    va_list args;
    va_start(args, format);
    int result = str_format_v(buffer, buffer_size, format, args);
    va_end(args);
    return result;
}

int str_format_v(char* buffer, size_t buffer_size, const char* format, va_list args) {
    if (!buffer || buffer_size == 0 || !format) return -1;
#if PLATFORM_WINDOWS
    return _vsnprintf_s(buffer, buffer_size, _TRUNCATE, format, args);
#else
    return vsnprintf(buffer, buffer_size, format, args);
#endif
}

int str_scan(const char* buffer, const char* format, ...) {
    va_list args;
    va_start(args, format);
    int result = vsscanf(buffer, format, args);
    va_end(args);
    return result;
}

} // namespace core

// ============================================================================
// StringMap Implementation
// ============================================================================

namespace core {

StringMap::StringMap() : m_map(64) {}

StringMap::~StringMap() {
    clear();
}

bool StringMap::insert(const std::string& key, void* value, size_t value_size) {
    // Free existing value if present
    auto* existing = m_map.find(key);
    if (existing) {
        std::free(existing->value);
    } else {
        // Allocate new entry
        void* value_copy = std::malloc(value_size);
        if (!value_copy) return false;
        std::memcpy(value_copy, value, value_size);
        return m_map.insert(key, Entry(key, value_copy, value_size));
    }
    return true;
}

void* StringMap::find(const std::string& key) {
    auto* entry = m_map.find(key);
    return entry ? entry->value : nullptr;
}

const void* StringMap::find(const std::string& key) const {
    auto* entry = m_map.find(key);
    return entry ? entry->value : nullptr;
}

bool StringMap::remove(const std::string& key) {
    auto* entry = m_map.find(key);
    if (entry) {
        std::free(entry->value);
        return m_map.remove(key);
    }
    return false;
}

void StringMap::clear() {
    m_map.for_each([](const auto& pair) {
        std::free(pair.second.value);
    });
    m_map.clear();
}

size_t StringMap::size() const {
    return m_map.size();
}

bool StringMap::empty() const {
    return m_map.empty();
}

} // namespace core

// ============================================================================
// Application Entry Point
// ============================================================================

namespace core {

/**
 * Initialize the application
 */
bool application_init(HINSTANCE instance, int show_cmd) {
    auto& state = get_state();
    
    if (state.initialized) return true;
    
    state.instance_handle = instance;
    state.show_command = show_cmd;
    
    // Initialize performance counter
#if PLATFORM_WINDOWS
    LARGE_INTEGER freq;
    QueryPerformanceFrequency(&freq);
    state.performance_frequency = freq.QuadPart;
    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    state.start_time = now.QuadPart;
#endif
    
    // Initialize data structures
    state.string_table = new StringMap();
    state.handle_table = new core::HashMap<uint64_t, void*>(128);
    state.resource_table = new core::HashMap<std::string, void*>(64);
    
    // Initialize locale
    state.code_page = 65001; // UTF-8
    
    state.initialized = true;
    return true;
}

/**
 * Shutdown the application
 */
void application_shutdown() {
    auto& state = get_state();
    
    if (!state.initialized) return;
    
    // Cleanup data structures
    delete state.string_table;
    delete state.handle_table;
    delete state.resource_table;
    
    state.string_table = nullptr;
    state.handle_table = nullptr;
    state.resource_table = nullptr;
    
    state.initialized = false;
}

/**
 * Get application instance
 */
HINSTANCE application_get_instance() {
    return get_state().instance_handle;
}

/**
 * Get main window
 */
HWND application_get_window() {
    return get_state().main_window;
}

/**
 * Set main window
 */
void application_set_window(HWND window) {
    get_state().main_window = window;
}

/**
 * Get elapsed time in milliseconds
 */
uint64_t application_get_time_ms() {
    auto& state = get_state();
    if (state.performance_frequency == 0) return 0;
    
#if PLATFORM_WINDOWS
    LARGE_INTEGER now;
    QueryPerformanceCounter(&now);
    return static_cast<uint64_t>((now.QuadPart - state.start_time) * 1000 / state.performance_frequency);
#else
    return 0;
#endif
}

} // namespace core
