/**
 * EgonsExternalBase - Data Structures Implementation
 * Template implementations for HashMap, DynamicArray, BinaryTree, LinkedList
 */

#include "core/data_structures.h"

#include <algorithm>
#include <cstring>
#include <functional>

namespace core {

// ============================================================================
// HashMap Implementation
// ============================================================================

template<typename K, typename V>
HashMap<K, V>::HashMap(size_t bucket_count)
    : m_bucket_count(bucket_count), m_size(0), m_max_load_factor(0.75f) {
    m_buckets = new Node*[m_bucket_count]();
    std::memset(m_buckets, 0, sizeof(Node*) * m_bucket_count);
}

template<typename K, typename V>
HashMap<K, V>::~HashMap() {
    clear();
    delete[] m_buckets;
}

template<typename K, typename V>
bool HashMap<K, V>::insert(const K& key, const V& value) {
    size_t index = bucket_index(key);
    
    // Check if key already exists
    Node* current = m_buckets[index];
    while (current) {
        if (current->key == key) {
            current->value = value;
            return true;
        }
        current = current->next;
    }
    
    // Insert new node at head
    Node* new_node = new Node(key, value);
    new_node->next = m_buckets[index];
    m_buckets[index] = new_node;
    m_size++;
    
    // Check load factor
    if (static_cast<float>(m_size) / m_bucket_count > m_max_load_factor) {
        rehash(m_bucket_count * 2);
    }
    
    return true;
}

template<typename K, typename V>
V* HashMap<K, V>::find(const K& key) {
    size_t index = bucket_index(key);
    Node* current = m_buckets[index];
    while (current) {
        if (current->key == key) {
            return &current->value;
        }
        current = current->next;
    }
    return nullptr;
}

template<typename K, typename V>
const V* HashMap<K, V>::find(const K& key) const {
    size_t index = bucket_index(key);
    Node* current = m_buckets[index];
    while (current) {
        if (current->key == key) {
            return &current->value;
        }
        current = current->next;
    }
    return nullptr;
}

template<typename K, typename V>
bool HashMap<K, V>::remove(const K& key) {
    size_t index = bucket_index(key);
    Node* current = m_buckets[index];
    Node* prev = nullptr;
    
    while (current) {
        if (current->key == key) {
            if (prev) {
                prev->next = current->next;
            } else {
                m_buckets[index] = current->next;
            }
            delete current;
            m_size--;
            return true;
        }
        prev = current;
        current = current->next;
    }
    return false;
}

template<typename K, typename V>
void HashMap<K, V>::clear() {
    for (size_t i = 0; i < m_bucket_count; i++) {
        Node* current = m_buckets[i];
        while (current) {
            Node* next = current->next;
            delete current;
            current = next;
        }
        m_buckets[i] = nullptr;
    }
    m_size = 0;
}

template<typename K, typename V>
template<typename Func>
void HashMap<K, V>::for_each(Func func) const {
    for (size_t i = 0; i < m_bucket_count; i++) {
        Node* current = m_buckets[i];
        while (current) {
            func(current->key, current->value);
            current = current->next;
        }
    }
}

template<typename K, typename V>
size_t HashMap<K, V>::bucket_index(const K& key) const {
    return std::hash<K>{}(key) % m_bucket_count;
}

template<typename K, typename V>
void HashMap<K, V>::rehash(size_t new_bucket_count) {
    Node** new_buckets = new Node*[new_bucket_count]();
    std::memset(new_buckets, 0, sizeof(Node*) * new_bucket_count);
    
    // Rehash all entries
    for (size_t i = 0; i < m_bucket_count; i++) {
        Node* current = m_buckets[i];
        while (current) {
            Node* next = current->next;
            size_t new_index = std::hash<K>{}(current->key) % new_bucket_count;
            current->next = new_buckets[new_index];
            new_buckets[new_index] = current;
            current = next;
        }
    }
    
    delete[] m_buckets;
    m_buckets = new_buckets;
    m_bucket_count = new_bucket_count;
}

// ============================================================================
// DynamicArray Implementation
// ============================================================================

template<typename T>
DynamicArray<T>::DynamicArray() : m_data(nullptr), m_size(0), m_capacity(0) {}

template<typename T>
DynamicArray<T>::DynamicArray(size_t initial_capacity)
    : m_data(nullptr), m_size(0), m_capacity(0) {
    if (initial_capacity > 0) {
        m_data = static_cast<T*>(std::malloc(sizeof(T) * initial_capacity));
        m_capacity = initial_capacity;
    }
}

template<typename T>
DynamicArray<T>::~DynamicArray() {
    clear();
    std::free(m_data);
}

template<typename T>
T& DynamicArray<T>::operator[](size_t index) {
    return m_data[index];
}

template<typename T>
const T& DynamicArray<T>::operator[](size_t index) const {
    return m_data[index];
}

template<typename T>
T& DynamicArray<T>::front() {
    return m_data[0];
}

template<typename T>
const T& DynamicArray<T>::front() const {
    return m_data[0];
}

template<typename T>
T& DynamicArray<T>::back() {
    return m_data[m_size - 1];
}

template<typename T>
const T& DynamicArray<T>::back() const {
    return m_data[m_size - 1];
}

template<typename T>
void DynamicArray<T>::push_back(const T& value) {
    if (m_size >= m_capacity) {
        grow();
    }
    m_data[m_size++] = value;
}

template<typename T>
void DynamicArray<T>::pop_back() {
    if (m_size > 0) {
        m_size--;
    }
}

template<typename T>
void DynamicArray<T>::insert(size_t index, const T& value) {
    if (index > m_size) return;
    if (m_size >= m_capacity) {
        grow();
    }
    for (size_t i = m_size; i > index; i--) {
        m_data[i] = m_data[i - 1];
    }
    m_data[index] = value;
    m_size++;
}

template<typename T>
void DynamicArray<T>::erase(size_t index) {
    if (index >= m_size) return;
    for (size_t i = index; i < m_size - 1; i++) {
        m_data[i] = m_data[i + 1];
    }
    m_size--;
}

template<typename T>
void DynamicArray<T>::clear() {
    m_size = 0;
}

template<typename T>
void DynamicArray<T>::reserve(size_t new_capacity) {
    if (new_capacity > m_capacity) {
        m_data = static_cast<T*>(std::realloc(m_data, sizeof(T) * new_capacity));
        m_capacity = new_capacity;
    }
}

template<typename T>
void DynamicArray<T>::resize(size_t new_size) {
    if (new_size > m_capacity) {
        reserve(new_size);
    }
    m_size = new_size;
}

template<typename T>
void DynamicArray<T>::grow(size_t min_capacity) {
    size_t new_capacity = m_capacity == 0 ? 8 : m_capacity * 2;
    if (new_capacity < min_capacity) {
        new_capacity = min_capacity;
    }
    reserve(new_capacity);
}

// ============================================================================
// BinaryTree Implementation
// ============================================================================

template<typename K, typename V>
BinaryTree<K, V>::BinaryTree() : m_root(nullptr), m_size(0) {
    m_sentinel = new Node(K(), V());
    m_sentinel->color = NodeColor::Black;
    m_sentinel->left = m_sentinel;
    m_sentinel->right = m_sentinel;
    m_sentinel->parent = m_sentinel;
    m_root = m_sentinel;
}

template<typename K, typename V>
BinaryTree<K, V>::~BinaryTree() {
    destroy_tree(m_root);
    delete m_sentinel;
}

template<typename K, typename V>
bool BinaryTree<K, V>::insert(const K& key, const V& value) {
    Node* new_node = new Node(key, value);
    new_node->left = m_sentinel;
    new_node->right = m_sentinel;
    new_node->parent = m_sentinel;
    
    Node* current = m_root;
    Node* parent = m_sentinel;
    
    while (current != m_sentinel) {
        parent = current;
        if (key < current->key) {
            current = current->left;
        } else if (key > current->key) {
            current = current->right;
        } else {
            // Key already exists, update value
            current->value = value;
            delete new_node;
            return true;
        }
    }
    
    new_node->parent = parent;
    if (parent == m_sentinel) {
        m_root = new_node;
    } else if (key < parent->key) {
        parent->left = new_node;
    } else {
        parent->right = new_node;
    }
    
    insert_fixup(new_node);
    m_size++;
    return true;
}

template<typename K, typename V>
V* BinaryTree<K, V>::find(const K& key) {
    Node* node = find_node(key);
    return node ? &node->value : nullptr;
}

template<typename K, typename V>
const V* BinaryTree<K, V>::find(const K& key) const {
    Node* node = find_node(key);
    return node ? &node->value : nullptr;
}

template<typename K, typename V>
bool BinaryTree<K, V>::remove(const K& key) {
    // Simplified - full implementation would require delete_fixup
    return false;
}

template<typename K, typename V>
void BinaryTree<K, V>::clear() {
    destroy_tree(m_root);
    m_root = m_sentinel;
    m_size = 0;
}

template<typename K, typename V>
template<typename Func>
void BinaryTree<K, V>::in_order(Func func) const {
    in_order_recursive(m_root, func);
}

template<typename K, typename V>
template<typename Func>
void BinaryTree<K, V>::pre_order(Func func) const {
    // Simplified - would need recursive implementation
}

template<typename K, typename V>
void BinaryTree<K, V>::rotate_left(Node* node) {
    Node* right_child = node->right;
    node->right = right_child->left;
    
    if (right_child->left != m_sentinel) {
        right_child->left->parent = node;
    }
    
    right_child->parent = node->parent;
    
    if (node->parent == m_sentinel) {
        m_root = right_child;
    } else if (node == node->parent->left) {
        node->parent->left = right_child;
    } else {
        node->parent->right = right_child;
    }
    
    right_child->left = node;
    node->parent = right_child;
}

template<typename K, typename V>
void BinaryTree<K, V>::rotate_right(Node* node) {
    Node* left_child = node->left;
    node->left = left_child->right;
    
    if (left_child->right != m_sentinel) {
        left_child->right->parent = node;
    }
    
    left_child->parent = node->parent;
    
    if (node->parent == m_sentinel) {
        m_root = left_child;
    } else if (node == node->parent->right) {
        node->parent->right = left_child;
    } else {
        node->parent->left = left_child;
    }
    
    left_child->right = node;
    node->parent = left_child;
}

template<typename K, typename V>
void BinaryTree<K, V>::insert_fixup(Node* node) {
    while (node->parent->color == NodeColor::Red) {
        if (node->parent == node->parent->parent->left) {
            Node* uncle = node->parent->parent->right;
            if (uncle->color == NodeColor::Red) {
                node->parent->color = NodeColor::Black;
                uncle->color = NodeColor::Black;
                node->parent->parent->color = NodeColor::Red;
                node = node->parent->parent;
            } else {
                if (node == node->parent->right) {
                    node = node->parent;
                    rotate_left(node);
                }
                node->parent->color = NodeColor::Black;
                node->parent->parent->color = NodeColor::Red;
                rotate_right(node->parent->parent);
            }
        } else {
            Node* uncle = node->parent->parent->left;
            if (uncle->color == NodeColor::Red) {
                node->parent->color = NodeColor::Black;
                uncle->color = NodeColor::Black;
                node->parent->parent->color = NodeColor::Red;
                node = node->parent->parent;
            } else {
                if (node == node->parent->left) {
                    node = node->parent;
                    rotate_right(node);
                }
                node->parent->color = NodeColor::Black;
                node->parent->parent->color = NodeColor::Red;
                rotate_left(node->parent->parent);
            }
        }
    }
    m_root->color = NodeColor::Black;
}

template<typename K, typename V>
void BinaryTree<K, V>::delete_fixup(Node* node) {
    // Simplified - full implementation would handle all cases
}

template<typename K, typename V>
void BinaryTree<K, V>::transplant(Node* old_node, Node* new_node) {
    if (old_node->parent == m_sentinel) {
        m_root = new_node;
    } else if (old_node == old_node->parent->left) {
        old_node->parent->left = new_node;
    } else {
        old_node->parent->right = new_node;
    }
    new_node->parent = old_node->parent;
}

template<typename K, typename V>
typename BinaryTree<K, V>::Node* BinaryTree<K, V>::minimum(Node* node) const {
    while (node->left != m_sentinel) {
        node = node->left;
    }
    return node;
}

template<typename K, typename V>
typename BinaryTree<K, V>::Node* BinaryTree<K, V>::find_node(const K& key) const {
    Node* current = m_root;
    while (current != m_sentinel) {
        if (key < current->key) {
            current = current->left;
        } else if (key > current->key) {
            current = current->right;
        } else {
            return current;
        }
    }
    return nullptr;
}

template<typename K, typename V>
void BinaryTree<K, V>::destroy_tree(Node* node) {
    if (node != m_sentinel) {
        destroy_tree(node->left);
        destroy_tree(node->right);
        delete node;
    }
}

template<typename K, typename V>
void BinaryTree<K, V>::in_order_recursive(Node* node, auto&& func) const {
    if (node != m_sentinel) {
        in_order_recursive(node->left, func);
        func(node->key, node->value);
        in_order_recursive(node->right, func);
    }
}

// ============================================================================
// LinkedList Implementation
// ============================================================================

template<typename T>
LinkedList<T>::LinkedList() : m_head(nullptr), m_tail(nullptr), m_size(0) {}

template<typename T>
LinkedList<T>::~LinkedList() {
    clear();
}

template<typename T>
T& LinkedList<T>::front() {
    return m_head->value;
}

template<typename T>
const T& LinkedList<T>::front() const {
    return m_head->value;
}

template<typename T>
T& LinkedList<T>::back() {
    return m_tail->value;
}

template<typename T>
const T& LinkedList<T>::back() const {
    return m_tail->value;
}

template<typename T>
void LinkedList<T>::push_front(const T& value) {
    Node* new_node = new Node(value);
    new_node->next = m_head;
    if (m_head) {
        m_head->prev = new_node;
    }
    m_head = new_node;
    if (!m_tail) {
        m_tail = new_node;
    }
    m_size++;
}

template<typename T>
void LinkedList<T>::push_back(const T& value) {
    Node* new_node = new Node(value);
    new_node->prev = m_tail;
    if (m_tail) {
        m_tail->next = new_node;
    }
    m_tail = new_node;
    if (!m_head) {
        m_head = new_node;
    }
    m_size++;
}

template<typename T>
void LinkedList<T>::pop_front() {
    if (!m_head) return;
    Node* old_head = m_head;
    m_head = m_head->next;
    if (m_head) {
        m_head->prev = nullptr;
    } else {
        m_tail = nullptr;
    }
    delete old_head;
    m_size--;
}

template<typename T>
void LinkedList<T>::pop_back() {
    if (!m_tail) return;
    Node* old_tail = m_tail;
    m_tail = m_tail->prev;
    if (m_tail) {
        m_tail->next = nullptr;
    } else {
        m_head = nullptr;
    }
    delete old_tail;
    m_size--;
}

template<typename T>
void LinkedList<T>::insert(Node* pos, const T& value) {
    if (!pos) {
        push_back(value);
        return;
    }
    Node* new_node = new Node(value);
    new_node->next = pos;
    new_node->prev = pos->prev;
    if (pos->prev) {
        pos->prev->next = new_node;
    }
    pos->prev = new_node;
    if (pos == m_head) {
        m_head = new_node;
    }
    m_size++;
}

template<typename T>
void LinkedList<T>::erase(Node* node) {
    if (!node) return;
    if (node->prev) {
        node->prev->next = node->next;
    } else {
        m_head = node->next;
    }
    if (node->next) {
        node->next->prev = node->prev;
    } else {
        m_tail = node->prev;
    }
    delete node;
    m_size--;
}

template<typename T>
void LinkedList<T>::clear() {
    Node* current = m_head;
    while (current) {
        Node* next = current->next;
        delete current;
        current = next;
    }
    m_head = nullptr;
    m_tail = nullptr;
    m_size = 0;
}

template<typename T>
void LinkedList<T>::splice(LinkedList& other) {
    if (other.empty()) return;
    if (empty()) {
        m_head = other.m_head;
        m_tail = other.m_tail;
    } else {
        m_tail->next = other.m_head;
        other.m_head->prev = m_tail;
        m_tail = other.m_tail;
    }
    m_size += other.m_size;
    other.m_head = nullptr;
    other.m_tail = nullptr;
    other.m_size = 0;
}

template<typename T>
void LinkedList<T>::reverse() {
    Node* current = m_head;
    while (current) {
        std::swap(current->next, current->prev);
        current = current->prev;
    }
    std::swap(m_head, m_tail);
}

template<typename T>
void LinkedList<T>::sort() {
    // Simplified - would need merge sort implementation
}

template<typename T>
template<typename Func>
void LinkedList<T>::for_each(Func func) const {
    Node* current = m_head;
    while (current) {
        func(current->value);
        current = current->next;
    }
}

} // namespace core
