/**
 * EgonsExternalBase - Main Entry Point
 * Example application demonstrating the restructured codebase
 */

#include "core/common.h"
#include "core/memory.h"
#include "core/strings.h"
#include "core/data_structures.h"
#include "crt/runtime.h"
#include "crt/stdio_redirect.h"

#if PLATFORM_WINDOWS
#include "platform/windows_api.h"
#include "platform/exception_handling.h"
#endif

#include <cstdio>
#include <cstring>

// ============================================================================
// Example Application
// ============================================================================

/**
 * Demonstrates the restructured codebase functionality
 */
int main(int argc, char* argv[]) {
    // Initialize CRT
    crt::init();
    crt::stdio_init();
    
    printf("EgonsExternalBase - Restructured C++ Project\n");
    printf("==========================================\n\n");
    
    // Demonstrate memory management
    printf("--- Memory Management ---\n");
    void* ptr = core::mem_alloc(1024);
    if (ptr) {
        printf("Allocated 1024 bytes at %p\n", ptr);
        core::mem_free(ptr);
        printf("Freed memory\n");
    }
    
    // Demonstrate string operations
    printf("\n--- String Operations ---\n");
    const char* test_str = "Hello, World!";
    size_t len = core::str_length(test_str);
    printf("String: \"%s\"\n", test_str);
    printf("Length: %zu\n", len);
    
    char buffer[256];
    core::str_copy(buffer, test_str, sizeof(buffer));
    printf("Copied: \"%s\"\n", buffer);
    
    int cmp = core::str_compare_nt(test_str, "Hello, World!");
    printf("Comparison result: %d\n", cmp);
    
    // Demonstrate hash map
    printf("\n--- Hash Map ---\n");
    core::HashMap<std::string, int> map;
    map.insert("apple", 1);
    map.insert("banana", 2);
    map.insert("cherry", 3);
    
    auto* value = map.find("banana");
    if (value) {
        printf("Found 'banana' -> %d\n", *value);
    }
    
    // Demonstrate dynamic array
    printf("\n--- Dynamic Array ---\n");
    core::DynamicArray<int> arr;
    for (int i = 0; i < 5; i++) {
        arr.push_back(i * 10);
    }
    
    printf("Array contents: ");
    for (size_t i = 0; i < arr.size(); i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    
    // Demonstrate binary tree
    printf("\n--- Binary Tree ---\n");
    core::BinaryTree<int, std::string> tree;
    tree.insert(5, "five");
    tree.insert(3, "three");
    tree.insert(7, "seven");
    tree.insert(1, "one");
    tree.insert(9, "nine");
    
    auto* tree_val = tree.find(7);
    if (tree_val) {
        printf("Found 7 -> \"%s\"\n", tree_val->c_str());
    }
    
    // Demonstrate string map
    printf("\n--- String Map ---\n");
    core::StringMap str_map;
    int val1 = 100;
    int val2 = 200;
    str_map.insert("key1", &val1, sizeof(val1));
    str_map.insert("key2", &val2, sizeof(val2));
    
    void* found = str_map.find("key1");
    if (found) {
        printf("Found 'key1' -> %d\n", *static_cast<int*>(found));
    }
    
    // Demonstrate FNV-1a hash
    printf("\n--- FNV-1a Hash ---\n");
    const char* hash_test = "test_string";
    uint64_t hash = core::fnv1a_hash(hash_test, strlen(hash_test));
    printf("Hash of \"%s\": 0x%016llx\n", hash_test, static_cast<unsigned long long>(hash));
    
    // Platform-specific demonstration
#if PLATFORM_WINDOWS
    printf("\n--- Platform Information ---\n");
    printf("Process ID: %lu\n", process_get_id());
    printf("Thread ID: %lu\n", thread_get_id());
    printf("Tick Count: %llu ms\n", system_get_tick_count());
    
    SYSTEMTIME st;
    time_get_local(&st);
    printf("Local Time: %04u-%02u-%02u %02u:%02u:%02u\n",
           st.wYear, st.wMonth, st.wDay,
           st.wHour, st.wMinute, st.wSecond);
#endif
    
    printf("\n--- CRT Functions ---\n");
    printf("Code Page: %lu\n", crt::get_code_page());
    printf("Last Error: %lu\n", crt::get_last_error());
    
    // Cleanup
    crt::stdio_shutdown();
    crt::terminate();
    
    printf("\nApplication completed successfully.\n");
    return 0;
}

#if PLATFORM_WINDOWS

/**
 * Windows entry point (WinMain)
 * Uncomment if building as a Windows GUI application
 */
/*
int WINAPI wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    LPWSTR lpCmdLine, int nShowCmd) {
    // Initialize application
    core::application_init(hInstance, nShowCmd);
    
    // Run main logic
    int result = main(0, nullptr);
    
    // Shutdown application
    core::application_shutdown();
    
    return result;
}
*/

#endif // PLATFORM_WINDOWS
