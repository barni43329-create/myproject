/**
 * EgonsExternalBase - CRT Runtime Implementation
 * Provides CRT functions referenced in the decompilation
 */

#include "crt/runtime.h"
#include "core/common.h"

#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cstdarg>
#include <cctype>
#include <cmath>
#include <ctime>
#include <cerrno>
#include <cfloat>
#include <climits>
#include <cassert>

// ============================================================================
// Runtime State
// ============================================================================

namespace {

struct CrtState {
    bool initialized = false;
    void* process_heap = nullptr;
    uint32_t error_mode = 0;
    uint32_t code_page = 65001; // UTF-8
    void (*invalid_parameter_handler)(const wchar_t*, const wchar_t*, const wchar_t*, uint32_t, uintptr_t) = nullptr;
    void (*pure_call_handler)() = nullptr;
    void* new_handler = nullptr;
    int new_mode = 0;
    uint32_t fp_control = 0;
    uint32_t fp_status = 0;
    void* locale_info = nullptr;
    void* tls_data = nullptr;
    int atexit_count = 0;
    static constexpr int MAX_ATEXIT = 32;
    void (*atexit_functions[MAX_ATEXIT])(void) = {};
    
    CrtState() {
        std::memset(atexit_functions, 0, sizeof(atexit_functions));
    }
};

CrtState& get_crt_state() {
    static CrtState state;
    return state;
}

} // anonymous namespace

namespace crt {

// ============================================================================
// Runtime Initialization
// ============================================================================

void init() {
    auto& state = get_crt_state();
    if (state.initialized) return;
    
#if PLATFORM_WINDOWS
    state.process_heap = GetProcessHeap();
#else
    state.process_heap = nullptr;
#endif
    
    state.initialized = true;
}

void terminate() {
    auto& state = get_crt_state();
    
    // Execute atexit functions
    execute_atexit();
    
    state.initialized = false;
}

void init_multibyte() {
    auto& state = get_crt_state();
    state.code_page = 65001; // UTF-8
}

void update_locale_info(void* context, void** locale_data) {
    // Simplified - in the original this would update locale info
}

void update_locale_info_mb(void* context, void** locale_data) {
    // Simplified - in the original this would update locale info
}

void lock(int section_index) {
    // Simplified - in the original this would lock a CRT section
}

void unlock(int section_index) {
    // Simplified - in the original this would unlock a CRT section
}

// ============================================================================
// Argument Parsing
// ============================================================================

void parse_command_line() {
    // Simplified - in the original this would parse the command line
}

wchar_t** get_command_line(int* argc) {
#if PLATFORM_WINDOWS
    static int arg_count = 0;
    static wchar_t** args = nullptr;
    
    if (!args) {
        args = CommandLineToArgvW(GetCommandLineW(), &arg_count);
    }
    
    if (argc) *argc = arg_count;
    return args;
#else
    static wchar_t* args[] = { nullptr };
    if (argc) *argc = 0;
    return args;
#endif
}

wchar_t** get_environment() {
#if PLATFORM_WINDOWS
    return _wgetenv(nullptr);
#else
    return nullptr;
#endif
}

// ============================================================================
// Exit Handling
// ============================================================================

int register_atexit(void (*func)(void)) {
    auto& state = get_crt_state();
    if (state.atexit_count < CrtState::MAX_ATEXIT) {
        state.atexit_functions[state.atexit_count++] = func;
        return 0;
    }
    return -1;
}

void execute_atexit() {
    auto& state = get_crt_state();
    for (int i = state.atexit_count - 1; i >= 0; i--) {
        if (state.atexit_functions[i]) {
            state.atexit_functions[i]();
        }
    }
    state.atexit_count = 0;
}

[[noreturn]] void exit_process(int code) {
    terminate();
    ExitProcess(code);
}

[[noreturn]] void quick_exit(int code) {
    terminate();
    _exit(code);
}

[[noreturn]] void abort_process() {
    terminate();
    abort();
}

void set_abort_message(const wchar_t* message) {
    // Simplified - in the original this would set abort message
}

// ============================================================================
// Error Handling
// ============================================================================

[[noreturn]] void invoke_watson(const wchar_t* expression, const wchar_t* function_name,
                                 const wchar_t* file_name, uint32_t line, uintptr_t reserved) {
    // Simplified - in the original this would invoke Watson error reporting
    abort();
}

int set_error_mode(int mode) {
    auto& state = get_crt_state();
    int old_mode = state.error_mode;
    state.error_mode = mode;
#if PLATFORM_WINDOWS
    SetErrorMode(mode);
#endif
    return old_mode;
}

uint32_t get_last_error() {
#if PLATFORM_WINDOWS
    return GetLastError();
#else
    return errno;
#endif
}

void set_last_error(uint32_t error) {
#if PLATFORM_WINDOWS
    SetLastError(error);
#else
    errno = error;
#endif
}

const char* get_error_string(uint32_t error) {
    static char buffer[256];
#if PLATFORM_WINDOWS
    FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                   nullptr, error, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                   buffer, sizeof(buffer), nullptr);
#else
    strerror_r(error, buffer, sizeof(buffer));
#endif
    return buffer;
}

// ============================================================================
// Locale Support
// ============================================================================

void* get_localeinfo() {
    return get_crt_state().locale_info;
}

char* set_lc(int category, const char* locale) {
    return setlocale(category, locale);
}

const char* get_current_locale_name() {
    return setlocale(LC_ALL, nullptr);
}

void* configure_new_handler() {
    return get_crt_state().new_handler;
}

// ============================================================================
// Multi-byte Support
// ============================================================================

void init_multibyte_tables() {
    // Simplified - in the original this would initialize multi-byte tables
}

uint32_t get_code_page() {
    return get_crt_state().code_page;
}

uint32_t get_acp() {
#if PLATFORM_WINDOWS
    return GetACP();
#else
    return 65001; // UTF-8
#endif
}

void* get_thread_mb_info() {
    return get_crt_state().tls_data;
}

// ============================================================================
// Floating Point
// ============================================================================

uint32_t get_floating_point_precision() {
    return get_crt_state().fp_control;
}

uint32_t set_floating_point_control(uint32_t new_control, uint32_t mask) {
    auto& state = get_crt_state();
    uint32_t old = state.fp_control;
    state.fp_control = (old & ~mask) | (new_control & mask);
    return old;
}

uint32_t get_floating_point_status() {
    return get_crt_state().fp_status;
}

uint32_t clear_floating_point_status(uint32_t mask) {
    auto& state = get_crt_state();
    uint32_t old = state.fp_status;
    state.fp_status &= ~mask;
    return old;
}

int check_floating_point_exception(uint32_t exception) {
    return (get_crt_state().fp_status & exception) != 0;
}

// ============================================================================
// Heap Management
// ============================================================================

void* get_process_heap() {
    return get_crt_state().process_heap;
}

void* heap_alloc(void* heap, uint32_t flags, size_t size) {
#if PLATFORM_WINDOWS
    return HeapAlloc(heap, flags, size);
#else
    return malloc(size);
#endif
}

void* heap_realloc(void* heap, uint32_t flags, void* ptr, size_t size) {
#if PLATFORM_WINDOWS
    return HeapReAlloc(heap, flags, ptr, size);
#else
    return realloc(ptr, size);
#endif
}

bool heap_free(void* heap, uint32_t flags, void* ptr) {
#if PLATFORM_WINDOWS
    return HeapFree(heap, flags, ptr) != FALSE;
#else
    free(ptr);
    return true;
#endif
}

size_t heap_size(void* heap, uint32_t flags, const void* ptr) {
#if PLATFORM_WINDOWS
    return HeapSize(heap, flags, ptr);
#else
    return malloc_usable_size(const_cast<void*>(ptr));
#endif
}

bool heap_validate(void* heap, uint32_t flags, const void* ptr) {
#if PLATFORM_WINDOWS
    return HeapValidate(heap, flags, ptr) != FALSE;
#else
    return true;
#endif
}

size_t heap_compact(void* heap, uint32_t flags) {
#if PLATFORM_WINDOWS
    return HeapCompact(heap, flags);
#else
    return 0;
#endif
}

bool heap_destroy(void* heap) {
#if PLATFORM_WINDOWS
    return HeapDestroy(heap) != FALSE;
#else
    return true;
#endif
}

bool heap_lock(void* heap) {
#if PLATFORM_WINDOWS
    return HeapLock(heap) != FALSE;
#else
    return true;
#endif
}

bool heap_unlock(void* heap) {
#if PLATFORM_WINDOWS
    return HeapUnlock(heap) != FALSE;
#else
    return true;
#endif
}

// ============================================================================
// Parameter Validation
// ============================================================================

void validate_parameter(const wchar_t* expression, const wchar_t* function_name,
                        const wchar_t* file_name, uint32_t line, uintptr_t reserved) {
    // Simplified - in the original this would validate parameters
}

void invalid_parameter_handler(const wchar_t* expression, const wchar_t* function_name,
                                const wchar_t* file_name, uint32_t line, uintptr_t reserved) {
    auto& state = get_crt_state();
    if (state.invalid_parameter_handler) {
        state.invalid_parameter_handler(expression, function_name, file_name, line, reserved);
    }
}

void set_invalid_parameter_handler(void (*handler)(const wchar_t*, const wchar_t*,
                                                     const wchar_t*, uint32_t, uintptr_t)) {
    get_crt_state().invalid_parameter_handler = handler;
}

void purge_invalid_parameter_handler() {
    get_crt_state().invalid_parameter_handler = nullptr;
}

// ============================================================================
// Security
// ============================================================================

void security_check_cookie(uintptr_t cookie) {
    if (cookie == 0) {
        security_report_failure();
    }
}

uintptr_t security_setup_cookie() {
    return guard_setup_cookie();
}

[[noreturn]] void security_report_failure() {
    abort();
}

void security_check_stack_corruption() {
    // Simplified - in the original this would check for stack corruption
}

// ============================================================================
// Signal Handling
// ============================================================================

SignalHandler set_signal(int signal, SignalHandler handler) {
    return ::signal(signal, handler);
}

void raise_signal(int signal) {
    ::raise(signal);
}

void call_signal_handler(int signal) {
    auto handler = ::signal(signal, SIG_DFL);
    if (handler != SIG_ERR && handler != SIG_DFL && handler != SIG_IGN) {
        ::signal(signal, handler);
        handler(signal);
    }
}

// ============================================================================
// Pure Call Handling
// ============================================================================

[[noreturn]] void pure_call_handler() {
    auto& state = get_crt_state();
    if (state.pure_call_handler) {
        state.pure_call_handler();
    }
    abort();
}

void set_pure_call_handler(void (*handler)()) {
    get_crt_state().pure_call_handler = handler;
}

void (*get_pure_call_handler())() {
    return get_crt_state().pure_call_handler;
}

// ============================================================================
// New Handler
// ============================================================================

NewHandler set_new_handler(NewHandler handler) {
    auto& state = get_crt_state();
    NewHandler old = static_cast<NewHandler>(state.new_handler);
    state.new_handler = handler;
    return old;
}

NewHandler get_new_handler() {
    return static_cast<NewHandler>(get_crt_state().new_handler);
}

void set_new_mode(int mode) {
    get_crt_state().new_mode = mode;
}

int get_new_mode() {
    return get_crt_state().new_mode;
}

// ============================================================================
// Memory Management
// ============================================================================

void* allocate_memory(size_t size) {
    return std::malloc(size);
}

void free_memory(void* ptr) {
    std::free(ptr);
}

void* reallocate_memory(void* ptr, size_t new_size) {
    return std::realloc(ptr, new_size);
}

size_t get_memory_size(const void* ptr) {
#if PLATFORM_WINDOWS
    return _msize(const_cast<void*>(ptr));
#else
    return malloc_usable_size(const_cast<void*>(ptr));
#endif
}

void* allocate_aligned_memory(size_t size, size_t alignment) {
#if PLATFORM_WINDOWS
    return _aligned_malloc(size, alignment);
#else
    void* ptr = nullptr;
    posix_memalign(&ptr, alignment, size);
    return ptr;
#endif
}

void free_aligned_memory(void* ptr) {
#if PLATFORM_WINDOWS
    _aligned_free(ptr);
#else
    free(ptr);
#endif
}

void* allocate_zeroed_memory(size_t count, size_t size) {
    return std::calloc(count, size);
}

void* allocate_copied_memory(const void* ptr, size_t size) {
    void* new_ptr = std::malloc(size);
    if (new_ptr) {
        std::memcpy(new_ptr, ptr, size);
    }
    return new_ptr;
}

// ============================================================================
// String Management
// ============================================================================

char* duplicate_string(const char* str) {
    if (!str) return nullptr;
    size_t len = std::strlen(str) + 1;
    char* new_str = static_cast<char*>(std::malloc(len));
    if (new_str) {
        std::memcpy(new_str, str, len);
    }
    return new_str;
}

wchar_t* duplicate_wstring(const wchar_t* wstr) {
    if (!wstr) return nullptr;
    size_t len = (std::wcslen(wstr) + 1) * sizeof(wchar_t);
    wchar_t* new_wstr = static_cast<wchar_t*>(std::malloc(len));
    if (new_wstr) {
        std::memcpy(new_wstr, wstr, len);
    }
    return new_wstr;
}

char* duplicate_string_n(const char* str, size_t length) {
    if (!str) return nullptr;
    char* new_str = static_cast<char*>(std::malloc(length + 1));
    if (new_str) {
        std::memcpy(new_str, str, length);
        new_str[length] = '\0';
    }
    return new_str;
}

wchar_t* duplicate_wstring_n(const wchar_t* wstr, size_t length) {
    if (!wstr) return nullptr;
    wchar_t* new_wstr = static_cast<wchar_t*>(std::malloc((length + 1) * sizeof(wchar_t)));
    if (new_wstr) {
        std::wcsncpy(new_wstr, wstr, length);
        new_wstr[length] = L'\0';
    }
    return new_wstr;
}

char* concatenate_strings(const char* str1, const char* str2) {
    if (!str1 || !str2) return nullptr;
    size_t len1 = std::strlen(str1);
    size_t len2 = std::strlen(str2);
    char* result = static_cast<char*>(std::malloc(len1 + len2 + 1));
    if (result) {
        std::memcpy(result, str1, len1);
        std::memcpy(result + len1, str2, len2 + 1);
    }
    return result;
}

wchar_t* concatenate_wstrings(const wchar_t* wstr1, const wchar_t* wstr2) {
    if (!wstr1 || !wstr2) return nullptr;
    size_t len1 = std::wcslen(wstr1);
    size_t len2 = std::wcslen(wstr2);
    wchar_t* result = static_cast<wchar_t*>(std::malloc((len1 + len2 + 1) * sizeof(wchar_t)));
    if (result) {
        std::memcpy(result, wstr1, len1 * sizeof(wchar_t));
        std::memcpy(result + len1, wstr2, (len2 + 1) * sizeof(wchar_t));
    }
    return result;
}

// ============================================================================
// Wide String Conversion
// ============================================================================

int wide_to_multi_byte(const wchar_t* wstr, int wstr_length, char* str, int str_length) {
#if PLATFORM_WINDOWS
    return WideCharToMultiByte(CP_ACP, 0, wstr, wstr_length, str, str_length, nullptr, nullptr);
#else
    return std::wcstombs(str, wstr, str_length);
#endif
}

int multi_byte_to_wide(const char* str, int str_length, wchar_t* wstr, int wstr_length) {
#if PLATFORM_WINDOWS
    return MultiByteToWideChar(CP_ACP, 0, str, str_length, wstr, wstr_length);
#else
    return std::mbstowcs(wstr, str, wstr_length);
#endif
}

int wide_to_multi_byte_cp(uint32_t code_page, const wchar_t* wstr, int wstr_length,
                           char* str, int str_length) {
#if PLATFORM_WINDOWS
    return WideCharToMultiByte(code_page, 0, wstr, wstr_length, str, str_length, nullptr, nullptr);
#else
    return std::wcstombs(str, wstr, str_length);
#endif
}

int multi_byte_to_wide_cp(uint32_t code_page, const char* str, int str_length,
                           wchar_t* wstr, int wstr_length) {
#if PLATFORM_WINDOWS
    return MultiByteToWideChar(code_page, 0, str, str_length, wstr, wstr_length);
#else
    return std::mbstowcs(wstr, str, wstr_length);
#endif
}

// ============================================================================
// Locale-dependent String Comparison
// ============================================================================

int compare_string_lcid(uint32_t lcid, const char* str1, int length1, const char* str2, int length2) {
#if PLATFORM_WINDOWS
    return CompareStringA(lcid, 0, str1, length1, str2, length2) - 2;
#else
    return strncmp(str1, str2, std::min(length1, length2));
#endif
}

int compare_wstring_lcid(uint32_t lcid, const wchar_t* str1, int length1,
                          const wchar_t* str2, int length2) {
#if PLATFORM_WINDOWS
    return CompareStringW(lcid, 0, str1, length1, str2, length2) - 2;
#else
    return wcsncmp(str1, str2, std::min(length1, length2));
#endif
}

int compare_string_cp(uint32_t code_page, const char* str1, int length1,
                       const char* str2, int length2) {
#if PLATFORM_WINDOWS
    return CompareStringA(MAKELCID(MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), SORT_DEFAULT),
                          0, str1, length1, str2, length2) - 2;
#else
    return strncmp(str1, str2, std::min(length1, length2));
#endif
}

int compare_wstring_cp(uint32_t code_page, const wchar_t* str1, int length1,
                        const wchar_t* str2, int length2) {
#if PLATFORM_WINDOWS
    return CompareStringW(MAKELCID(MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), SORT_DEFAULT),
                          0, str1, length1, str2, length2) - 2;
#else
    return wcsncmp(str1, str2, std::min(length1, length2));
#endif
}

// ============================================================================
// Ctype Functions
// ============================================================================

const unsigned short* get_ctype_info() {
    return __pctype_func();
}

const unsigned char* get_clmap_info() {
    return _pclmap;
}

const unsigned char* get_cumap_info() {
    return _pcumap;
}

void* get_ctype_locale() {
    return get_crt_state().locale_info;
}

void set_ctype_locale(void* locale) {
    get_crt_state().locale_info = locale;
}

// ============================================================================
// Math Functions
// ============================================================================

double math_floor(double value) { return std::floor(value); }
double math_ceil(double value) { return std::ceil(value); }
double math_round(double value) { return std::round(value); }
double math_truncate(double value) { return std::trunc(value); }
double math_abs(double value) { return std::fabs(value); }
double math_pow(double base, double exponent) { return std::pow(base, exponent); }
double math_sqrt(double value) { return std::sqrt(value); }
double math_log(double value) { return std::log(value); }
double math_log10(double value) { return std::log10(value); }
double math_exp(double value) { return std::exp(value); }
double math_sin(double value) { return std::sin(value); }
double math_cos(double value) { return std::cos(value); }
double math_tan(double value) { return std::tan(value); }
double math_asin(double value) { return std::asin(value); }
double math_acos(double value) { return std::acos(value); }
double math_atan(double value) { return std::atan(value); }
double math_atan2(double y, double x) { return std::atan2(y, x); }

int math_fpclassify(double value) {
    return std::fpclassify(value);
}

int math_isfinite(double value) { return std::isfinite(value); }
int math_isinf(double value) { return std::isinf(value); }
int math_isnan(double value) { return std::isnan(value); }
int math_isnormal(double value) { return std::isnormal(value); }

// ============================================================================
// Random Number Generation
// ============================================================================

void random_seed(uint32_t seed) {
    std::srand(seed);
}

uint32_t random_generate() {
    return std::rand();
}

uint32_t random_generate_range(uint32_t min, uint32_t max) {
    return min + (std::rand() % (max - min + 1));
}

double random_generate_double() {
    return static_cast<double>(std::rand()) / RAND_MAX;
}

// ============================================================================
// Environment
// ============================================================================

wchar_t* get_environment_variable(const wchar_t* name) {
#if PLATFORM_WINDOWS
    return _wgetenv(name);
#else
    return nullptr;
#endif
}

bool set_environment_variable(const wchar_t* name, const wchar_t* value) {
#if PLATFORM_WINDOWS
    return _wputenv_s(name, value) == 0;
#else
    return false;
#endif
}

wchar_t** get_environment_strings() {
#if PLATFORM_WINDOWS
    return _wenviron;
#else
    return nullptr;
#endif
}

bool free_environment_strings(wchar_t** strings) {
    // Environment strings are static, nothing to free
    return true;
}

void get_startup_info(void* startup_info) {
#if PLATFORM_WINDOWS
    GetStartupInfoW(static_cast<LPSTARTUPINFOW>(startup_info));
#endif
}

// ============================================================================
// Console
// ============================================================================

bool ensure_console_output() {
#if PLATFORM_WINDOWS
    static HANDLE console_handle = INVALID_HANDLE_VALUE;
    if (console_handle == INVALID_HANDLE_VALUE) {
        console_handle = CreateFileW(L"CONOUT$", GENERIC_WRITE, FILE_SHARE_WRITE,
                                      nullptr, OPEN_EXISTING, 0, nullptr);
    }
    return console_handle != INVALID_HANDLE_VALUE;
#else
    return true;
#endif
}

bool write_console(HANDLE console, const void* buffer, uint32_t length, uint32_t* written) {
#if PLATFORM_WINDOWS
    return WriteConsoleW(console, buffer, length, reinterpret_cast<LPDWORD>(written), nullptr) != FALSE;
#else
    return fwrite(buffer, 1, length, stdout) == length;
#endif
}

bool read_console(HANDLE console, void* buffer, uint32_t length, uint32_t* read) {
#if PLATFORM_WINDOWS
    return ReadConsoleW(console, buffer, length, reinterpret_cast<LPDWORD>(read), nullptr) != FALSE;
#else
    return fread(buffer, 1, length, stdin) == length;
#endif
}

bool get_console_mode(HANDLE console, uint32_t* mode) {
#if PLATFORM_WINDOWS
    return GetConsoleMode(console, reinterpret_cast<LPDWORD>(mode)) != FALSE;
#else
    return false;
#endif
}

bool set_console_mode(HANDLE console, uint32_t mode) {
#if PLATFORM_WINDOWS
    return SetConsoleMode(console, mode) != FALSE;
#else
    return false;
#endif
}

uint32_t get_console_output_cp() {
#if PLATFORM_WINDOWS
    return GetConsoleOutputCP();
#else
    return 65001;
#endif
}

bool set_console_output_cp(uint32_t code_page) {
#if PLATFORM_WINDOWS
    return SetConsoleOutputCP(code_page) != FALSE;
#else
    return false;
#endif
}

uint32_t get_console_cp() {
#if PLATFORM_WINDOWS
    return GetConsoleCP();
#else
    return 65001;
#endif
}

bool set_console_cp(uint32_t code_page) {
#if PLATFORM_WINDOWS
    return SetConsoleCP(code_page) != FALSE;
#else
    return false;
#endif
}

// ============================================================================
// Standard I/O
// ============================================================================

HANDLE get_std_handle(uint32_t std_handle) {
#if PLATFORM_WINDOWS
    return GetStdHandle(std_handle);
#else
    return nullptr;
#endif
}

bool set_std_handle(uint32_t std_handle, HANDLE handle) {
#if PLATFORM_WINDOWS
    return SetStdHandle(std_handle, handle) != FALSE;
#else
    return false;
#endif
}

int get_std_handle_number(HANDLE handle) {
#if PLATFORM_WINDOWS
    if (handle == GetStdHandle(STD_INPUT_HANDLE)) return 0;
    if (handle == GetStdHandle(STD_OUTPUT_HANDLE)) return 1;
    if (handle == GetStdHandle(STD_ERROR_HANDLE)) return 2;
#endif
    return -1;
}

bool write_file(HANDLE file, const void* buffer, uint32_t length, uint32_t* written, void* overlapped) {
#if PLATFORM_WINDOWS
    return WriteFile(file, buffer, length, reinterpret_cast<LPDWORD>(written),
                     static_cast<LPOVERLAPPED>(overlapped)) != FALSE;
#else
    return fwrite(buffer, 1, length, stdout) == length;
#endif
}

bool read_file(HANDLE file, void* buffer, uint32_t length, uint32_t* read, void* overlapped) {
#if PLATFORM_WINDOWS
    return ReadFile(file, buffer, length, reinterpret_cast<LPDWORD>(read),
                    static_cast<LPOVERLAPPED>(overlapped)) != FALSE;
#else
    return fread(buffer, 1, length, stdin) == length;
#endif
}

bool flush_file_buffers(HANDLE file) {
#if PLATFORM_WINDOWS
    return FlushFileBuffers(file) != FALSE;
#else
    return fflush(nullptr) == 0;
#endif
}

uint32_t get_file_type(HANDLE file) {
#if PLATFORM_WINDOWS
    return GetFileType(file);
#else
    return 0;
#endif
}

bool get_file_info_by_handle(HANDLE file, void* file_info) {
#if PLATFORM_WINDOWS
    return GetFileInformationByHandle(file, static_cast<LPBY_HANDLE_FILE_INFORMATION>(file_info)) != FALSE;
#else
    return false;
#endif
}

bool get_file_info_by_handle_ex(HANDLE file, void* file_info) {
#if PLATFORM_WINDOWS
    return GetFileInformationByHandleEx(file, FileBasicInfo, file_info, sizeof(FILE_BASIC_INFO)) != FALSE;
#else
    return false;
#endif
}

bool set_file_pointer_ex(HANDLE file, int64_t distance, int64_t* new_pointer, uint32_t move_method) {
#if PLATFORM_WINDOWS
    LARGE_INTEGER li;
    li.QuadPart = distance;
    LARGE_INTEGER new_pos;
    BOOL result = SetFilePointerEx(file, li, &new_pos, move_method);
    if (new_pointer) *new_pointer = new_pos.QuadPart;
    return result != FALSE;
#else
    return false;
#endif
}

bool lock_file_ex(HANDLE file, uint32_t flags, uint32_t reserved, uint32_t length_low,
                   uint32_t length_high, void* overlapped) {
#if PLATFORM_WINDOWS
    return LockFileEx(file, flags, reserved, length_low, length_high,
                      static_cast<LPOVERLAPPED>(overlapped)) != FALSE;
#else
    return false;
#endif
}

bool unlock_file_ex(HANDLE file, uint32_t reserved, uint32_t length_low, uint32_t length_high,
                     void* overlapped) {
#if PLATFORM_WINDOWS
    return UnlockFileEx(file, reserved, length_low, length_high,
                        static_cast<LPOVERLAPPED>(overlapped)) != FALSE;
#else
    return false;
#endif
}

bool write_file_ex(HANDLE file, const void* buffer, uint32_t length, void* overlapped,
                    void (*completion_routine)(uint32_t, uint32_t, void*)) {
#if PLATFORM_WINDOWS
    return WriteFileEx(file, buffer, length, static_cast<LPOVERLAPPED>(overlapped),
                       reinterpret_cast<LPOVERLAPPED_COMPLETION_ROUTINE>(completion_routine)) != FALSE;
#else
    return false;
#endif
}

bool read_file_ex(HANDLE file, void* buffer, uint32_t length, void* overlapped,
                   void (*completion_routine)(uint32_t, uint32_t, void*)) {
#if PLATFORM_WINDOWS
    return ReadFileEx(file, buffer, length, static_cast<LPOVERLAPPED>(overlapped),
                      reinterpret_cast<LPOVERLAPPED_COMPLETION_ROUTINE>(completion_routine)) != FALSE;
#else
    return false;
#endif
}

} // namespace crt
