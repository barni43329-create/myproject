/**
 * EgonsExternalBase - CRT Stdio Redirect
 * Handles stdio redirection found in the decompilation
 */

#include "crt/stdio_redirect.h"
#include "core/common.h"

#include <cstdio>
#include <cstring>

namespace crt {

// ============================================================================
// Stdio State
// ============================================================================

namespace {

struct StdioState {
    bool initialized = false;
    FILE* stdin_handle = nullptr;
    FILE* stdout_handle = nullptr;
    FILE* stderr_handle = nullptr;
    HANDLE stdin_real = nullptr;
    HANDLE stdout_real = nullptr;
    HANDLE stderr_real = nullptr;
    
    StdioState() = default;
};

StdioState& get_stdio_state() {
    static StdioState state;
    return state;
}

} // anonymous namespace

// ============================================================================
// Stdio Initialization
// ============================================================================

void stdio_init() {
    auto& state = get_stdio_state();
    if (state.initialized) return;
    
    state.stdin_handle = stdin;
    state.stdout_handle = stdout;
    state.stderr_handle = stderr;
    
#if PLATFORM_WINDOWS
    state.stdin_real = GetStdHandle(STD_INPUT_HANDLE);
    state.stdout_real = GetStdHandle(STD_OUTPUT_HANDLE);
    state.stderr_real = GetStdHandle(STD_ERROR_HANDLE);
#endif
    
    state.initialized = true;
}

void stdio_shutdown() {
    auto& state = get_stdio_state();
    if (!state.initialized) return;
    
    fflush(stdout);
    fflush(stderr);
    
    state.initialized = false;
}

// ============================================================================
// Stdio Redirection
// ============================================================================

bool stdio_redirect_stdin(const char* filename) {
    return freopen(filename, "r", stdin) != nullptr;
}

bool stdio_redirect_stdout(const char* filename) {
    return freopen(filename, "w", stdout) != nullptr;
}

bool stdio_redirect_stderr(const char* filename) {
    return freopen(filename, "w", stderr) != nullptr;
}

bool stdio_redirect_stdout_append(const char* filename) {
    return freopen(filename, "a", stdout) != nullptr;
}

void stdio_restore_stdin() {
    auto& state = get_stdio_state();
    if (state.stdin_handle) {
        stdin = state.stdin_handle;
    }
}

void stdio_restore_stdout() {
    auto& state = get_stdio_state();
    if (state.stdout_handle) {
        stdout = state.stdout_handle;
    }
}

void stdio_restore_stderr() {
    auto& state = get_stdio_state();
    if (state.stderr_handle) {
        stderr = state.stderr_handle;
    }
}

// ============================================================================
// Console Output
// ============================================================================

int console_print(const char* message) {
    return printf("%s", message);
}

int console_print_format(const char* format, ...) {
    va_list args;
    va_start(args, format);
    int result = vprintf(format, args);
    va_end(args);
    return result;
}

int console_print_error(const char* message) {
    return fprintf(stderr, "%s", message);
}

int console_print_error_format(const char* format, ...) {
    va_list args;
    va_start(args, format);
    int result = vfprintf(stderr, format, args);
    va_end(args);
    return result;
}

// ============================================================================
// Console Input
// ============================================================================

char* console_read_line(char* buffer, int buffer_size) {
    return fgets(buffer, buffer_size, stdin);
}

int console_read_char() {
    return fgetc stdin);
}

// ============================================================================
// File I/O
// ============================================================================

FILE* file_open(const char* filename, const char* mode) {
    return fopen(filename, mode);
}

void file_close(FILE* file) {
    if (file) fclose(file);
}

size_t file_read(void* buffer, size_t size, size_t count, FILE* file) {
    return fread(buffer, size, count, file);
}

size_t file_write(const void* buffer, size_t size, size_t count, FILE* file) {
    return fwrite(buffer, size, count, file);
}

int file_seek(FILE* file, long offset, int origin) {
    return fseek(file, offset, origin);
}

long file_tell(FILE* file) {
    return ftell(file);
}

int file_flush(FILE* file) {
    return fflush(file);
}

int file_eof(FILE* file) {
    return feof(file);
}

int file_error(FILE* file) {
    return ferror(file);
}

void file_clear_error(FILE* file) {
    clearerr(file);
}

// ============================================================================
// Formatted I/O
// ============================================================================

int format_string(char* buffer, size_t buffer_size, const char* format, ...) {
    va_list args;
    va_start(args, format);
    int result = vsnprintf(buffer, buffer_size, format, args);
    va_end(args);
    return result;
}

int format_string_v(char* buffer, size_t buffer_size, const char* format, va_list args) {
    return vsnprintf(buffer, buffer_size, format, args);
}

int parse_string(const char* buffer, const char* format, ...) {
    va_list args;
    va_start(args, format);
    int result = vsscanf(buffer, format, args);
    va_end(args);
    return result;
}

// ============================================================================
// Character Classification
// ============================================================================

int char_is_alpha(int ch) {
    return isalpha(static_cast<unsigned char>(ch));
}

int char_is_digit(int ch) {
    return isdigit(static_cast<unsigned char>(ch));
}

int char_is_alphanumeric(int ch) {
    return isalnum(static_cast<unsigned char>(ch));
}

int char_is_space(int ch) {
    return isspace(static_cast<unsigned char>(ch));
}

int char_is_printable(int ch) {
    return isprint(static_cast<unsigned char>(ch));
}

int char_is_upper(int ch) {
    return isupper(static_cast<unsigned char>(ch));
}

int char_is_lower(int ch) {
    return islower(static_cast<unsigned char>(ch));
}

int char_to_upper(int ch) {
    return toupper(static_cast<unsigned char>(ch));
}

int char_to_lower(int ch) {
    return tolower(static_cast<unsigned char>(ch));
}

// ============================================================================
// Conversion Functions
// ============================================================================

int string_to_int(const char* str) {
    return static_cast<int>(strtol(str, nullptr, 10));
}

long string_to_long(const char* str) {
    return strtol(str, nullptr, 10);
}

long long string_to_long_long(const char* str) {
    return strtoll(str, nullptr, 10);
}

unsigned long string_to_unsigned_long(const char* str) {
    return strtoul(str, nullptr, 10);
}

unsigned long long string_to_unsigned_long_long(const char* str) {
    return strtoull(str, nullptr, 10);
}

float string_to_float(const char* str) {
    return strtof(str, nullptr);
}

double string_to_double(const char* str) {
    return strtod(str, nullptr);
}

long double string_to_long_double(const char* str) {
    return strtold(str, nullptr);
}

// ============================================================================
// Buffer Operations
// ============================================================================

void* buffer_copy(void* dest, const void* src, size_t count) {
    return memcpy(dest, src, count);
}

void* buffer_move(void* dest, const void* src, size_t count) {
    return memmove(dest, src, count);
}

void* buffer_set(void* dest, int value, size_t count) {
    return memset(dest, value, count);
}

int buffer_compare(const void* buf1, const void* buf2, size_t count) {
    return memcmp(buf1, buf2, count);
}

const void* buffer_find(const void* buf, int value, size_t count) {
    return memchr(buf, value, count);
}

} // namespace crt
