/**
 * EgonsExternalBase - Windows API Implementation
 * Encapsulates Windows API calls with error handling
 */

#include "platform/windows_api.h"

#if PLATFORM_WINDOWS

namespace platform {

// ============================================================================
// Process and Thread Management
// ============================================================================

HANDLE process_get_current() {
    return GetCurrentProcess();
}

uint32_t process_get_id() {
    return GetCurrentProcessId();
}

uint32_t thread_get_id() {
    return GetCurrentThreadId();
}

bool process_create(const wchar_t* application_name, const wchar_t* command_line,
                    HANDLE* process_handle, HANDLE* thread_handle) {
    STARTUPINFOW si = { sizeof(si) };
    PROCESS_INFORMATION pi = {};
    
    BOOL result = CreateProcessW(
        application_name,
        const_cast<LPWSTR>(command_line),
        nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi
    );
    
    if (result) {
        if (process_handle) *process_handle = pi.hProcess;
        if (thread_handle) *thread_handle = pi.hThread;
        return true;
    }
    return false;
}

bool process_terminate(HANDLE process, uint32_t exit_code) {
    return TerminateProcess(process, exit_code) != FALSE;
}

HMODULE module_get_handle(const wchar_t* module_name) {
    return GetModuleHandleW(module_name);
}

FARPROC module_get_proc(HMODULE module, const char* proc_name) {
    return GetProcAddress(module, proc_name);
}

bool module_get_filename(HMODULE module, wchar_t* buffer, uint32_t buffer_size) {
    return GetModuleFileNameW(module, buffer, buffer_size) != 0;
}

// ============================================================================
// File System Operations
// ============================================================================

HANDLE file_create(const wchar_t* path, uint32_t desired_access, uint32_t share_mode,
                   uint32_t creation_disposition, uint32_t flags) {
    return CreateFileW(path, desired_access, share_mode, nullptr,
                       creation_disposition, flags, nullptr);
}

void file_close(HANDLE file) {
    if (file != INVALID_HANDLE_VALUE) {
        CloseHandle(file);
    }
}

bool file_read(HANDLE file, void* buffer, uint32_t bytes_to_read, uint32_t* bytes_read) {
    DWORD read = 0;
    BOOL result = ReadFile(file, buffer, bytes_to_read, &read, nullptr);
    if (bytes_read) *bytes_read = read;
    return result != FALSE;
}

bool file_write(HANDLE file, const void* buffer, uint32_t bytes_to_write, uint32_t* bytes_written) {
    DWORD written = 0;
    BOOL result = WriteFile(file, buffer, bytes_to_write, &written, nullptr);
    if (bytes_written) *bytes_written = written;
    return result != FALSE;
}

uint64_t file_get_size(HANDLE file) {
    LARGE_INTEGER size;
    if (GetFileSizeEx(file, &size)) {
        return size.QuadPart;
    }
    return 0;
}

int64_t file_set_pointer(HANDLE file, int64_t distance, uint32_t move_method) {
    LARGE_INTEGER li;
    li.QuadPart = distance;
    LARGE_INTEGER new_pos;
    if (SetFilePointerEx(file, li, &new_pos, move_method)) {
        return new_pos.QuadPart;
    }
    return -1;
}

bool file_delete(const wchar_t* path) {
    return DeleteFileW(path) != FALSE;
}

bool file_exists(const wchar_t* path) {
    DWORD attribs = GetFileAttributesW(path);
    return (attribs != INVALID_FILE_ATTRIBUTES && !(attribs & FILE_ATTRIBUTE_DIRECTORY));
}

HANDLE file_find_first(const wchar_t* path, WIN32_FIND_DATAW* find_data) {
    return FindFirstFileW(path, find_data);
}

bool file_find_next(HANDLE find_handle, WIN32_FIND_DATAW* find_data) {
    return FindNextFileW(find_handle, find_data) != FALSE;
}

void file_find_close(HANDLE find_handle) {
    if (find_handle != INVALID_HANDLE_VALUE) {
        FindClose(find_handle);
    }
}

// ============================================================================
// Registry Operations
// ============================================================================

bool registry_open(HKEY parent, const wchar_t* subkey, uint32_t options, HKEY* result) {
    return RegOpenKeyExW(parent, subkey, options, KEY_READ | KEY_WRITE, result) == ERROR_SUCCESS;
}

void registry_close(HKEY key) {
    RegCloseKey(key);
}

bool registry_read_string(HKEY key, const wchar_t* value_name, wchar_t* buffer, uint32_t buffer_size) {
    DWORD size = buffer_size;
    return RegQueryValueExW(key, value_name, nullptr, nullptr,
                            reinterpret_cast<LPBYTE>(buffer), &size) == ERROR_SUCCESS;
}

bool registry_read_dword(HKEY key, const wchar_t* value_name, uint32_t* value) {
    DWORD size = sizeof(DWORD);
    return RegQueryValueExW(key, value_name, nullptr, nullptr,
                            reinterpret_cast<LPBYTE>(value), &size) == ERROR_SUCCESS;
}

bool registry_write_string(HKEY key, const wchar_t* value_name, const wchar_t* value) {
    return RegSetValueExW(key, value_name, 0, REG_SZ,
                          reinterpret_cast<const BYTE*>(value),
                          (wcslen(value) + 1) * sizeof(wchar_t)) == ERROR_SUCCESS;
}

bool registry_write_dword(HKEY key, const wchar_t* value_name, uint32_t value) {
    return RegSetValueExW(key, value_name, 0, REG_DWORD,
                          reinterpret_cast<const BYTE*>(&value),
                          sizeof(DWORD)) == ERROR_SUCCESS;
}

// ============================================================================
// Window Management
// ============================================================================

ATOM window_register_class(const WNDCLASSEXW* window_class) {
    return RegisterClassExW(window_class);
}

HWND window_create(const wchar_t* class_name, const wchar_t* window_name, uint32_t style,
                   int x, int y, int width, int height, HWND parent, HMENU menu,
                   HINSTANCE instance) {
    return CreateWindowExW(0, class_name, window_name, style, x, y, width, height,
                           parent, menu, instance, nullptr);
}

bool window_destroy(HWND window) {
    return DestroyWindow(window) != FALSE;
}

bool window_show(HWND window, int show_command) {
    return ShowWindow(window, show_command) != FALSE;
}

bool window_update(HWND window) {
    return UpdateWindow(window) != FALSE;
}

bool window_get_message(MSG* msg, HWND window, uint32_t filter_min, uint32_t filter_max) {
    return GetMessageW(msg, window, filter_min, filter_max) > 0;
}

bool window_translate_message(const MSG* msg) {
    return TranslateMessage(msg) != FALSE;
}

LRESULT window_dispatch_message(const MSG* msg) {
    return DispatchMessageW(msg);
}

LRESULT window_send_message(HWND window, uint32_t msg, WPARAM wparam, LPARAM lparam) {
    return SendMessageW(window, msg, wparam, lparam);
}

bool window_post_message(HWND window, uint32_t msg, WPARAM wparam, LPARAM lparam) {
    return PostMessageW(window, msg, wparam, lparam) != FALSE;
}

void window_post_quit(int exit_code) {
    PostQuitMessage(exit_code);
}

LRESULT window_def_proc(HWND window, uint32_t msg, WPARAM wparam, LPARAM lparam) {
    return DefWindowProcW(window, msg, wparam, lparam);
}

int window_get_text(HWND window, wchar_t* buffer, int max_count) {
    return GetWindowTextW(window, buffer, max_count);
}

bool window_set_text(HWND window, const wchar_t* text) {
    return SetWindowTextW(window, text) != FALSE;
}

bool window_get_rect(HWND window, RECT* rect) {
    return GetWindowRect(window, rect) != FALSE;
}

bool window_set_pos(HWND window, HWND insert_after, int x, int y, int cx, int cy, uint32_t flags) {
    return SetWindowPos(window, insert_after, x, y, cx, cy, flags) != FALSE;
}

bool window_get_client_rect(HWND window, RECT* rect) {
    return GetClientRect(window, rect) != FALSE;
}

bool window_invalidate(HWND window, const RECT* rect, bool erase) {
    return InvalidateRect(window, rect, erase ? TRUE : FALSE) != FALSE;
}

HDC window_begin_paint(HWND window, PAINTSTRUCT* paint) {
    return BeginPaint(window, paint);
}

bool window_end_paint(HWND window, const PAINTSTRUCT* paint) {
    return EndPaint(window, paint) != FALSE;
}

// ============================================================================
// Device Context Operations
// ============================================================================

HDC dc_create_compatible(HDC dc) {
    return CreateCompatibleDC(dc);
}

bool dc_delete(HDC dc) {
    return DeleteDC(dc) != FALSE;
}

HGDIOBJ dc_select_object(HDC dc, HGDIOBJ object) {
    return SelectObject(dc, object);
}

HBRUSH brush_create_solid(uint32_t color) {
    return CreateSolidBrush(color);
}

bool gdi_delete_object(HGDIOBJ object) {
    return DeleteObject(object) != FALSE;
}

HFONT font_create(int height, int width, int escapement, int orientation,
                  int weight, bool italic, bool underline, bool strike_out,
                  const wchar_t* face_name) {
    return CreateFontW(height, width, escapement, orientation, weight,
                       italic ? TRUE : FALSE, underline ? TRUE : FALSE,
                       strike_out ? TRUE : FALSE, DEFAULT_CHARSET,
                       OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                       DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, face_name);
}

bool dc_text_out(HDC dc, int x, int y, const wchar_t* text, int length) {
    return TextOutW(dc, x, y, text, length) != FALSE;
}

bool dc_get_text_extent(HDC dc, const wchar_t* text, int length, SIZE* size) {
    return GetTextExtentPoint32W(dc, text, length, size) != FALSE;
}

// ============================================================================
// Resource Management
// ============================================================================

HRSRC resource_find(HMODULE module, const wchar_t* name, const wchar_t* type) {
    return FindResourceW(module, name, type);
}

HGLOBAL resource_load(HMODULE module, HRSRC resource) {
    return LoadResource(module, resource);
}

void* resource_lock(HGLOBAL resource) {
    return LockResource(resource);
}

uint32_t resource_size(HMODULE module, HRSRC resource) {
    return SizeofResource(module, resource);
}

int resource_load_string(HMODULE module, uint32_t id, wchar_t* buffer, int buffer_size) {
    return LoadStringW(module, id, buffer, buffer_size);
}

// ============================================================================
// Clipboard Operations
// ============================================================================

bool clipboard_open(HWND window) {
    return OpenClipboard(window) != FALSE;
}

bool clipboard_close() {
    return CloseClipboard() != FALSE;
}

bool clipboard_set_data(uint32_t format, HANDLE data) {
    return SetClipboardData(format, data) != nullptr;
}

HANDLE clipboard_get_data(uint32_t format) {
    return GetClipboardData(format);
}

bool clipboard_empty() {
    return EmptyClipboard() != FALSE;
}

// ============================================================================
// System Information
// ============================================================================

uint32_t system_get_directory(wchar_t* buffer, uint32_t size) {
    return GetSystemDirectoryW(buffer, size);
}

uint32_t system_get_windows_directory(wchar_t* buffer, uint32_t size) {
    return GetWindowsDirectoryW(buffer, size);
}

bool system_get_computer_name(wchar_t* buffer, uint32_t* size) {
    return GetComputerNameW(buffer, reinterpret_cast<LPDWORD>(size)) != FALSE;
}

bool system_get_user_name(wchar_t* buffer, uint32_t* size) {
    return GetUserNameW(buffer, reinterpret_cast<LPDWORD>(size)) != FALSE;
}

uint32_t system_get_version() {
    return GetVersion();
}

int system_get_metrics(int index) {
    return GetSystemMetrics(index);
}

uint64_t system_get_tick_count() {
    return GetTickCount64();
}

int64_t system_get_performance_counter() {
    LARGE_INTEGER counter;
    QueryPerformanceCounter(&counter);
    return counter.QuadPart;
}

int64_t system_get_performance_frequency() {
    LARGE_INTEGER frequency;
    QueryPerformanceFrequency(&frequency);
    return frequency.QuadPart;
}

// ============================================================================
// Time Functions
// ============================================================================

void time_get_local(SYSTEMTIME* time) {
    GetLocalTime(time);
}

void time_get_system(SYSTEMTIME* time) {
    GetSystemTime(time);
}

bool time_system_to_file(const SYSTEMTIME* st, FILETIME* ft) {
    return SystemTimeToFileTime(st, ft) != FALSE;
}

bool time_file_to_system(const FILETIME* ft, SYSTEMTIME* st) {
    return FileTimeToSystemTime(ft, st) != FALSE;
}

uint32_t time_get_timezone(TIME_ZONE_INFORMATION* tz_info) {
    return GetTimeZoneInformation(tz_info);
}

// ============================================================================
// Synchronization
// ============================================================================

void critical_section_init(CRITICAL_SECTION* cs) {
    InitializeCriticalSection(cs);
}

void critical_section_enter(CRITICAL_SECTION* cs) {
    EnterCriticalSection(cs);
}

void critical_section_leave(CRITICAL_SECTION* cs) {
    LeaveCriticalSection(cs);
}

bool critical_section_try_enter(CRITICAL_SECTION* cs) {
    return TryEnterCriticalSection(cs) != FALSE;
}

void critical_section_delete(CRITICAL_SECTION* cs) {
    DeleteCriticalSection(cs);
}

void srw_lock_init(SRWLOCK* lock) {
    InitializeSRWLock(lock);
}

void srw_lock_acquire_exclusive(SRWLOCK* lock) {
    AcquireSRWLockExclusive(lock);
}

void srw_lock_release_exclusive(SRWLOCK* lock) {
    ReleaseSRWLockExclusive(lock);
}

void srw_lock_acquire_shared(SRWLOCK* lock) {
    AcquireSRWLockShared(lock);
}

void srw_lock_release_shared(SRWLOCK* lock) {
    ReleaseSRWLockShared(lock);
}

// ============================================================================
// Socket Operations
// ============================================================================

bool socket_init(uint16_t version_requested) {
    WSADATA wsa_data;
    return WSAStartup(version_requested, &wsa_data) == 0;
}

void socket_cleanup() {
    WSACleanup();
}

uint64_t socket_create(int address_family, int socket_type, int protocol) {
    return static_cast<uint64_t>(::socket(address_family, socket_type, protocol));
}

int socket_close(uint64_t socket) {
    return ::closesocket(static_cast<SOCKET>(socket));
}

int socket_connect(uint64_t socket, const sockaddr* address, int address_length) {
    return ::connect(static_cast<SOCKET>(socket), address, address_length);
}

int socket_send(uint64_t socket, const char* buffer, int length, int flags) {
    return ::send(static_cast<SOCKET>(socket), buffer, length, flags);
}

int socket_recv(uint64_t socket, char* buffer, int length, int flags) {
    return ::recv(static_cast<SOCKET>(socket), buffer, length, flags);
}

int socket_bind(uint64_t socket, const sockaddr* address, int address_length) {
    return ::bind(static_cast<SOCKET>(socket), address, address_length);
}

int socket_listen(uint64_t socket, int backlog) {
    return ::listen(static_cast<SOCKET>(socket), backlog);
}

uint64_t socket_accept(uint64_t socket, sockaddr* address, int* address_length) {
    return static_cast<uint64_t>(::accept(static_cast<SOCKET>(socket), address, address_length));
}

int socket_set_option(uint64_t socket, int level, int option_name, const char* option_value, int option_length) {
    return ::setsockopt(static_cast<SOCKET>(socket), level, option_name, option_value, option_length);
}

int socket_get_option(uint64_t socket, int level, int option_name, char* option_value, int* option_length) {
    return ::getsockopt(static_cast<SOCKET>(socket), level, option_name, option_value, option_length);
}

int socket_get_hostname(char* name, int name_length) {
    return ::gethostname(name, name_length);
}

int socket_get_address_info(const char* node_name, const char* service_name,
                            const addrinfo* hints, addrinfo** result) {
    return ::getaddrinfo(node_name, service_name, hints, result);
}

void socket_free_address_info(addrinfo* info) {
    ::freeaddrinfo(info);
}

// ============================================================================
// Debugging
// ============================================================================

void debug_output(const wchar_t* string) {
    OutputDebugStringW(string);
}

bool debug_is_present() {
    return IsDebuggerPresent() != FALSE;
}

void debug_break() {
    __debugbreak();
}

uint32_t debug_get_thread_id() {
    return GetCurrentThreadId();
}

uint32_t debug_get_process_id() {
    return GetCurrentProcessId();
}

// ============================================================================
// Library Loading
// ============================================================================

HMODULE library_load(const wchar_t* filename) {
    return LoadLibraryW(filename);
}

HMODULE library_load_ex(const wchar_t* filename, HANDLE file, uint32_t flags) {
    return LoadLibraryExW(filename, file, flags);
}

bool library_free(HMODULE module) {
    return FreeLibrary(module) != FALSE;
}

FARPROC library_get_proc(HMODULE module, const char* proc_name) {
    return GetProcAddress(module, proc_name);
}

// ============================================================================
// Memory-Mapped Files
// ============================================================================

HANDLE mapping_create(HANDLE file, uint32_t protect, uint64_t maximum_size, const wchar_t* name) {
    LARGE_INTEGER size;
    size.QuadPart = maximum_size;
    return CreateFileMappingW(file, nullptr, protect, size.HighPart, size.LowPart, name);
}

void* mapping_map(HANDLE mapping, uint32_t desired_access, uint64_t file_offset, size_t number_of_bytes) {
    return MapViewOfFile(mapping, desired_access, static_cast<DWORD>(file_offset >> 32),
                        static_cast<DWORD>(file_offset), number_of_bytes);
}

bool mapping_unmap(const void* address) {
    return UnmapViewOfFile(address) != FALSE;
}

void mapping_close(HANDLE mapping) {
    CloseHandle(mapping);
}

// ============================================================================
// Dynamic Loading Helpers
// ============================================================================

HMODULE get_caller_module() {
    HMODULE module = nullptr;
    GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                       reinterpret_cast<LPCWSTR>(get_caller_module), &module);
    return module;
}

FARPROC get_export_by_ordinal(HMODULE module, uint16_t ordinal) {
    return GetProcAddress(module, MAKEINTRESOURCEA(ordinal));
}

FARPROC get_export_by_hash(HMODULE module, uint32_t name_hash) {
    auto* dos_header = reinterpret_cast<IMAGE_DOS_HEADER*>(module);
    if (dos_header->e_magic != IMAGE_DOS_SIGNATURE) return nullptr;
    
    auto* nt_headers = reinterpret_cast<IMAGE_NT_HEADERS*>(
        reinterpret_cast<uint8_t*>(module) + dos_header->e_lfanew);
    if (nt_headers->Signature != IMAGE_NT_SIGNATURE) return nullptr;
    
    auto& export_data = nt_headers->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    if (export_data.VirtualAddress == 0) return nullptr;
    
    auto* export_dir = reinterpret_cast<IMAGE_EXPORT_DIRECTORY*>(
        reinterpret_cast<uint8_t*>(module) + export_data.VirtualAddress);
    
    auto* names = reinterpret_cast<uint32_t*>(
        reinterpret_cast<uint8_t*>(module) + export_dir->AddressOfNames);
    auto* ordinals = reinterpret_cast<uint16_t*>(
        reinterpret_cast<uint8_t*>(module) + export_dir->AddressOfNameOrdinals);
    auto* functions = reinterpret_cast<uint32_t*>(
        reinterpret_cast<uint8_t*>(module) + export_dir->AddressOfFunctions);
    
    for (uint32_t i = 0; i < export_dir->NumberOfNames; i++) {
        const char* name = reinterpret_cast<const char*>(
            reinterpret_cast<uint8_t*>(module) + names[i]);
        
        // Simple hash (FNV-1a)
        uint32_t hash = 2166136261u;
        for (const char* p = name; *p; p++) {
            hash ^= static_cast<uint8_t>(*p);
            hash *= 16777619u;
        }
        
        if (hash == name_hash) {
            return reinterpret_cast<FARPROC>(
                reinterpret_cast<uint8_t*>(module) + functions[ordinals[i]]);
        }
    }
    return nullptr;
}

} // namespace platform

#endif // PLATFORM_WINDOWS
