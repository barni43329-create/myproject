/**
 * EgonsExternalBase - Platform Stub Implementation
 */

#include "platform/platform_stub.h"

#if !PLATFORM_WINDOWS

// This file provides stub implementations for non-Windows platforms
// Most functions are no-ops or return default values

#endif // !PLATFORM_WINDOWS
