/**
 * EgonsExternalBase - Exception Handling Implementation
 */

#include "platform/exception_handling.h"

#if PLATFORM_WINDOWS

namespace platform {

// ============================================================================
// Structured Exception Handling (SEH)
// ============================================================================

void* exception_register_vectored(Vectored_handler handler, bool first_handler) {
    return AddVectoredExceptionHandler(first_handler ? 1 : 0, handler);
}

uint32_t exception_remove_vectored(void* handle) {
    return RemoveVectoredExceptionHandler(handle);
}

void exception_set_unhandled_filter(ExceptionFilter filter) {
    SetUnhandledExceptionFilter(filter);
}

void exception_raise(uint32_t code, uint32_t flags, uint32_t argument_count,
                     const uintptr_t* arguments) {
    RaiseException(code, flags, argument_count, arguments);
}

void exception_continue() {
    // This would be implemented with _longjmp or similar in the original
    // For now, this is a placeholder
}

void exception_continue_search() {
    // This would be implemented with _longjmp or similar in the original
    // For now, this is a placeholder
}

// ============================================================================
// C++ Exception Handling
// ============================================================================

void cpp_throw(uint32_t code, void* exception_object) {
    // Simplified - in the original this would involve complex EH structures
    throw code;
}

uint32_t cpp_get_exception_code(const EXCEPTION_RECORD* record) {
    return record ? record->ExceptionCode : 0;
}

bool cpp_is_cpp_exception(const EXCEPTION_RECORD* record) {
    return record && record->ExceptionCode == 0xE06D7363;
}

void* cpp_get_exception_object(const EXCEPTION_RECORD* record) {
    if (record && record->NumberParameters > 1) {
        return reinterpret_cast<void*>(record->ExceptionInformation[1]);
    }
    return nullptr;
}

void cpp_set_exception_params(uint32_t magic, void* object, void* info) {
    // Simplified - in the original this would involve complex EH structures
}

void cpp_try_begin() {
    // Simplified - in the original this would involve complex EH structures
}

void cpp_try_end() {
    // Simplified - in the original this would involve complex EH structures
}

void cpp_catch(void* exception_type) {
    // Simplified - in the original this would involve complex EH structures
}

// ============================================================================
// Guard Security
// ============================================================================

void guard_validate_cookie(uintptr_t cookie) {
    if (cookie == 0) {
        // Security cookie validation failed
        __report_gsfailure();
    }
}

uintptr_t guard_check_cookie(uintptr_t cookie) {
    if (cookie == 0) {
        __report_gsfailure();
    }
    return cookie;
}

uintptr_t guard_setup_cookie() {
    // Generate a random security cookie
    uintptr_t cookie = 0;
    LARGE_INTEGER counter;
    QueryPerformanceCounter(&counter);
    cookie = counter.QuadPart ^ reinterpret_cast<uintptr_t>(GetCurrentProcess());
    cookie ^= reinterpret_cast<uintptr_t>(GetCurrentThread());
    return cookie;
}

void guard_report_failure() {
    __report_gsfailure();
}

// ============================================================================
// Stack Checking
// ============================================================================

void stack_probe(uintptr_t frame) {
    // Simplified - in the original this would probe stack pages
}

void stack_probe_all(uintptr_t frame) {
    // Simplified - in the original this would probe all stack pages
}

void stack_restore(uintptr_t frame) {
    // Simplified - in the original this would restore stack
}

// ============================================================================
// Runtime Function Lookup
// ============================================================================

PRUNTIME_FUNCTION runtime_lookup_function(uint64_t control_pc, void* context) {
    return RtlLookupFunctionEntry(control_pc, &control_pc, nullptr);
}

void* runtime_virtual_unwind(uint64_t handler_type, uint64_t image_base,
                              uint64_t control_pc, PRUNTIME_FUNCTION function_entry,
                              CONTEXT* context) {
    return RtlVirtualUnwind(handler_type, image_base, control_pc, function_entry,
                            context, nullptr, nullptr, nullptr);
}

void runtime_unwind_frame(void* frame, void* target_ip, CONTEXT* context,
                          void* history_table) {
    // Simplified - in the original this would unwind a stack frame
}

// ============================================================================
// Exception Dispatcher
// ============================================================================

void exception_dispatch(EXCEPTION_RECORD* record, CONTEXT* context) {
    // Simplified - in the original this would dispatch to appropriate handler
}

void exception_execute_handler(EXCEPTION_RECORD* record, void* handler, CONTEXT* context) {
    // Simplified - in the original this would execute the handler
}

void exception_execute_terminators() {
    // Simplified - in the original this would execute termination handlers
}

// ============================================================================
// Helper Functions
// ============================================================================

const char* exception_get_string(uint32_t code) {
    switch (code) {
        case EXCEPTION_ACCESS_VIOLATION:         return "Access Violation";
        case EXCEPTION_ARRAY_BOUNDS_EXCEEDED:    return "Array Bounds Exceeded";
        case EXCEPTION_BREAKPOINT:               return "Breakpoint";
        case EXCEPTION_DATATYPE_MISALIGNMENT:    return "Datatype Misalignment";
        case EXCEPTION_FLT_DIVIDE_BY_ZERO:       return "Float Divide by Zero";
        case EXCEPTION_FLT_OVERFLOW:             return "Float Overflow";
        case EXCEPTION_FLT_STACK_CHECK:          return "Float Stack Check";
        case EXCEPTION_FLT_UNDERFLOW:            return "Float Underflow";
        case EXCEPTION_ILLEGAL_INSTRUCTION:      return "Illegal Instruction";
        case EXCEPTION_IN_PAGE_ERROR:            return "In-Page Error";
        case EXCEPTION_INT_DIVIDE_BY_ZERO:       return "Integer Divide by Zero";
        case EXCEPTION_INT_OVERFLOW:             return "Integer Overflow";
        case EXCEPTION_INVALID_DISPOSITION:      return "Invalid Disposition";
        case EXCEPTION_NONCONTINUABLE_EXCEPTION: return "Noncontinuable Exception";
        case EXCEPTION_PRIV_INSTRUCTION:         return "Privileged Instruction";
        case EXCEPTION_SINGLE_STEP:              return "Single Step";
        case EXCEPTION_STACK_OVERFLOW:           return "Stack Overflow";
        case 0xE06D7363:                         return "C++ Exception";
        default:                                 return "Unknown Exception";
    }
}

void exception_format_record(const EXCEPTION_RECORD* record, char* buffer, size_t buffer_size) {
    if (!record || !buffer || buffer_size == 0) return;
    
    snprintf(buffer, buffer_size,
             "Exception: 0x%08X (%s) at address 0x%p\n"
             "Flags: 0x%08X\n"
             "Parameters: %u",
             record->ExceptionCode,
             exception_get_string(record->ExceptionCode),
             record->ExceptionAddress,
             record->ExceptionFlags,
             record->NumberParameters);
}

void exception_log(const EXCEPTION_RECORD* record) {
    char buffer[512];
    exception_format_record(record, buffer, sizeof(buffer));
    OutputDebugStringA(buffer);
}

bool exception_is_continuable(const EXCEPTION_RECORD* record) {
    return record && !(record->ExceptionFlags & EXCEPTION_NONCONTINUABLE);
}

void* exception_get_address(const EXCEPTION_RECORD* record) {
    return record ? record->ExceptionAddress : nullptr;
}

void exception_set_address(EXCEPTION_RECORD* record, void* address) {
    if (record) record->ExceptionAddress = address;
}

void exception_add_parameter(EXCEPTION_RECORD* record, uintptr_t parameter) {
    if (record && record->NumberParameters < EXCEPTION_MAXIMUM_PARAMETERS) {
        record->ExceptionInformation[record->NumberParameters++] = parameter;
    }
}

uintptr_t exception_get_parameter(const EXCEPTION_RECORD* record, uint32_t index) {
    if (record && index < record->NumberParameters) {
        return record->ExceptionInformation[index];
    }
    return 0;
}

} // namespace platform

#endif // PLATFORM_WINDOWS
