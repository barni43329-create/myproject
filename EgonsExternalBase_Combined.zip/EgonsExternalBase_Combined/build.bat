@echo off
REM ============================================================================
REM EgonsExternalBase + ImGui - Build Script
REM ============================================================================

if not defined BUILD_LAUNCHER (
    set BUILD_LAUNCHER=1
    cmd /k "%~f0"
    exit /b
)

echo.
echo ============================================================================
echo  EgonsExternalBase + ImGui Build
echo ============================================================================
echo.

REM ============================================================================
REM Detect compiler paths (avoiding parenthesis issues)
REM ============================================================================
echo [CHECK] Detecting compilers...
echo.

REM Get short paths to avoid parenthesis issues
for %%A in ("C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\bin\Hostx64\x64\cl.exe") do set VC_PATH=%%~dpA
for %%A in ("C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\include") do set VC_INCLUDE=%%~A
for %%A in ("C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC\14.44.35207\lib\x64") do set VC_LIB=%%~A

for %%A in ("C:\Program Files (x86)\Windows Kits\10\Include\10.0.26100.0") do set SDK_INCLUDE=%%~A
for %%A in ("C:\Program Files (x86)\Windows Kits\10\Lib\10.0.26100.0") do set SDK_LIB=%%~A

for %%A in ("C:\Program Files\CMake\bin\cmake.exe") do set CMAKE_PATH=%%~A

REM Remove trailing backslash from VC_PATH
if "%VC_PATH:~-1%"=="\" set VC_PATH=%VC_PATH:~0,-1%

REM ============================================================================
REM Verify compilers
REM ============================================================================
if not exist "%VC_PATH%\cl.exe" (
    echo [FAIL] MSVC not found at:
    echo        %VC_PATH%\cl.exe
    goto :ERROR
)
echo [OK]   MSVC

if not exist "%CMAKE_PATH%" (
    echo [FAIL] CMake not found at:
    echo        %CMAKE_PATH%
    goto :ERROR
)
echo [OK]   CMake

if not exist "%SDK_INCLUDE%" (
    echo [FAIL] Windows SDK not found at:
    echo        %SDK_INCLUDE%
    goto :ERROR
)
echo [OK]   Windows SDK

echo.

REM ============================================================================
REM Setup environment
REM ============================================================================
set PATH=%VC_PATH%;%CMAKE_PATH%;%PATH%
set INCLUDE=%VC_INCLUDE%;%SDK_INCLUDE%\um;%SDK_INCLUDE%\shared;%SDK_INCLUDE%\ucrt
set LIB=%VC_LIB%;%SDK_LIB%\um\x64;%SDK_LIB%\ucrt\x64

REM ============================================================================
REM Configure
REM ============================================================================
echo [1/2] Configuring...
echo.

if not exist build mkdir build
cd build

"%CMAKE_PATH%" .. -G "Visual Studio 17 2022" -A x64 -DCMAKE_CONFIGURATION_TYPES=Release
if %ERRORLEVEL% neq 0 (
    echo.
    echo [FAIL] CMake configure failed
    cd ..
    goto :ERROR
)

echo.
echo [OK]   Configured.
echo.

REM ============================================================================
REM Build
REM ============================================================================
echo [2/2] Building...
echo.

"%CMAKE_PATH%" --build . --config Release --parallel
if %ERRORLEVEL% neq 0 (
    echo.
    echo [FAIL] Build failed
    cd ..
    goto :ERROR
)

cd ..

REM ============================================================================
REM Success
REM ============================================================================
echo.
echo ============================================================================
echo  BUILD SUCCESSFUL
echo ============================================================================
echo.
echo Output: build\Release\EgonApp.exe
if exist build\Release\EgonApp.exe dir build\Release\EgonApp.exe | find "EgonApp.exe"
echo.
pause
goto :EOF

REM ============================================================================
REM Error handler
REM ============================================================================
:ERROR
echo.
echo Build failed with errors.
echo.
pause
goto :EOF
